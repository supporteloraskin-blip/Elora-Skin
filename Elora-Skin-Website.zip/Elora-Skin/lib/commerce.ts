export interface CommerceEnvironment {
  COMMERCE_PROVIDER?: string;
  SQUARESPACE_STORE_URL?: string;
  SQUARESPACE_READY?: string;
  SELFNAMED_READY?: string;
  SHOP_READY?: string;
  PRICES_APPROVED?: string;
}

export function secureStoreUrl(value?: string): string | null {
  if (!value) return null;
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.username || url.password || url.port || url.search || url.hash) return null;
    if (!url.hostname.includes('.') || /(^|\.)(localhost|local|internal|test|example|invalid)$/.test(url.hostname) || /^[\d.]+$/.test(url.hostname) || url.hostname.includes(':')) return null;
    return url.href;
  } catch { return null; }
}

export function commerceStatus(config: CommerceEnvironment) {
  const provider = config.COMMERCE_PROVIDER === 'stripe' ? 'stripe' : 'squarespace';
  const storeUrl = secureStoreUrl(config.SQUARESPACE_STORE_URL);
  const nativeReady = provider === 'squarespace' && config.SHOP_READY === 'true' && config.PRICES_APPROVED === 'true' && config.SQUARESPACE_READY === 'true' && config.SELFNAMED_READY === 'true' && !!storeUrl;
  return { provider, storeUrl: nativeReady ? storeUrl : null, nativeReady, cartTransfer: false, fulfillment: nativeReady ? 'native-squarespace-selfnamed' : 'not-connected' };
}
