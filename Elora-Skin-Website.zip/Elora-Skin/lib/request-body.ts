export class RequestBodyError extends Error {
  readonly code: 'payload_too_large' | 'invalid_body';

  constructor(code: 'payload_too_large' | 'invalid_body') {
    super(code === 'payload_too_large' ? 'Payload too large.' : 'Invalid request body.');
    this.name = 'RequestBodyError';
    this.code = code;
  }
}

/** Read actual bytes, including when Content-Length is absent or inaccurate. */
export async function readBoundedBody(request: Pick<Request, 'body'>, maxBytes: number): Promise<Uint8Array> {
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1) throw new RangeError('maxBytes must be a positive safe integer.');
  if (!request.body) return new Uint8Array();
  const reader = request.body.getReader();
  // A fixed bounded buffer also avoids unbounded bookkeeping for tiny chunks.
  const buffer = new Uint8Array(maxBytes);
  let size = 0;
  try {
    while (true) {
      const part = await reader.read();
      if (part.done) return buffer.slice(0, size);
      if (!(part.value instanceof Uint8Array)) throw new RequestBodyError('invalid_body');
      if (part.value.byteLength > maxBytes - size) throw new RequestBodyError('payload_too_large');
      buffer.set(part.value, size);
      size += part.value.byteLength;
    }
  } catch (error) {
    // Stop consuming an oversized or broken stream. Cancellation itself must
    // not turn the intended 413/400 into an unhandled exception.
    try { await reader.cancel(); } catch {}
    if (error instanceof RequestBodyError) throw error;
    throw new RequestBodyError('invalid_body');
  } finally {
    reader.releaseLock();
  }
}

export function decodeRequestBody(bytes: Uint8Array): string {
  try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
  catch { throw new RequestBodyError('invalid_body'); }
}

export async function readBoundedText(request: Pick<Request, 'body'>, maxBytes: number): Promise<string> {
  return decodeRequestBody(await readBoundedBody(request, maxBytes));
}
