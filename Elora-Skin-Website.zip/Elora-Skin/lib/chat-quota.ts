// Each statement reserves at most one allowance atomically, even with concurrent
// requests. D1 executes the group as a transaction with DB.batch().
export const reserveQuotaSql = 'INSERT INTO chat_rate_limits (bucket_key, used, expires_at) VALUES (?, 1, ?) ON CONFLICT(bucket_key) DO UPDATE SET used = used + 1 WHERE used < ? RETURNING used';
