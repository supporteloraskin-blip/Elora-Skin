export const AFTERSHIP_TRACKING_URL = 'https://supporteloraskinafte.aftership.com/?page-name=tracking-page';
