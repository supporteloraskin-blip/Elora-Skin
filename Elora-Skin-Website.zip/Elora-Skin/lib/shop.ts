import { env } from 'cloudflare:workers';
import ingredientConcepts from '../content/ingredient-concepts.json';
import { commerceStatus } from './commerce';
export const catalog={
 cleanser:{ingredientConcept:ingredientConcepts.products.cleanser,formulationStatus:'proposed',organicProductCertification:'unverified',name:'The Gentle Silk Cleanser',price:1600,size:'120 mL',category:'Cleanse'},
 serum:{ingredientConcept:ingredientConcepts.products.serum,formulationStatus:'proposed',organicProductCertification:'unverified',name:'Radiance Renewal Serum',price:2200,size:'30 mL',category:'Renew'},
 cream:{ingredientConcept:ingredientConcepts.products.cream,formulationStatus:'proposed',organicProductCertification:'unverified',name:'The Comfort Veil Face Cream',price:2300,size:'50 mL',category:'Comfort'},
 eye:{ingredientConcept:ingredientConcepts.products.eye,formulationStatus:'proposed',organicProductCertification:'unverified',name:'The Timeless Eye Cream',price:1800,size:'15 mL',category:'Care'},
};
export const upcomingCatalog={
 scrub:{name:"Gentle Facial Scrub",availability:'planned',purchasable:false,price:null,ingredientConcept:ingredientConcepts.products.scrub,formulationStatus:'proposed',organicProductCertification:'unverified'},
 sunscreen:{name:"Sunscreen",availability:'planned',purchasable:false,price:null,ingredientConcept:ingredientConcepts.products.sunscreen,formulationStatus:'proposed',organicProductCertification:'unverified'},
 pads:{name:"Cleansing Facial Pads",availability:'planned',purchasable:false,price:null,ingredientConcept:ingredientConcepts.products.pads,formulationStatus:'proposed',organicProductCertification:'unverified'},
 toner:{name:"Facial Toner",availability:'planned',purchasable:false,price:null,ingredientConcept:ingredientConcepts.products.toner,formulationStatus:'proposed',organicProductCertification:'unverified'}
};
export function checkoutReady(){
 const commerce=commerceStatus(env);
 if(commerce.provider==='squarespace')return commerce.nativeReady;
 return env.SHOP_READY==='true'&&env.PRICES_APPROVED==='true'&&!!env.STRIPE_SECRET_KEY&&!!env.STRIPE_WEBHOOK_SECRET&&/^\d+$/.test(env.SHIPPING_AMOUNT_CENTS||'')&&!!env.SHIPPING_COUNTRIES;
}
export function shopOrigin(request:Request){return new URL(request.url).origin;}
export function shopJson(value:unknown,status=200){return Response.json(value,{status,headers:{'Cache-Control':'no-store'}});}
