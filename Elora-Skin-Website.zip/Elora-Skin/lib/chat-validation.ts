export type ChatMessage = { role: 'user' | 'assistant'; content: string };

export function parseChatMessages(value: unknown): ChatMessage[] | null {
  if (!value || typeof value !== 'object' || !('messages' in value)) return null;
  const messages = (value as { messages: unknown }).messages;
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 10) return null;
  let total = 0;
  for (let i = 0; i < messages.length; i++) {
    const m = messages[i];
    if (!m || typeof m !== 'object' || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string') return null;
    if (!m.content.trim() || m.content.length > 1200 || (i && m.role === messages[i - 1].role)) return null;
    total += m.content.length;
  }
  if (total > 6500 || messages[0].role !== 'user' || messages.at(-1).role !== 'user') return null;
  return messages.map(m => ({ role: m.role, content: m.content.trim() }));
}

export function responseText(value: unknown): string | null {
  const output = (value as { output?: unknown[] } | null)?.output;
  if (!Array.isArray(output)) return null;
  const text = output.flatMap((item: any) => item?.type === 'message' && item.role === 'assistant' && Array.isArray(item.content)
    ? item.content.filter((part: any) => part?.type === 'output_text' && typeof part.text === 'string').map((part: any) => part.text) : []).join('\n').trim();
  return text ? text.slice(0, 5000) : null;
}

