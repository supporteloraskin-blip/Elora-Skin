/**
 * Read-only review publication boundary. Inputs must come from a server-side,
 * authenticated commerce adapter, never from a browser or a public form.
 * The native Squarespace/Selfnamed connection is not available yet.
 */
export type ReviewProductId = 'cleanser' | 'serum' | 'cream' | 'eye';
export interface TrustedOrderEvidence {
  orderKey: string;
  productIds: readonly string[];
  paymentStatus: string;
  fulfillmentStatus: string;
}
export interface ReviewCandidate {
  id: string;
  orderKey: string;
  productId: string;
  displayName: string;
  rating: number;
  title: string;
  text: string;
  createdAt: string;
  publicationConsent: boolean;
  moderationStatus: string;
}
export interface PublicCustomerReview {
  id: string;
  productId: ReviewProductId;
  displayName: string;
  rating: number;
  title: string;
  text: string;
  createdAt: string;
  verifiedPurchase: true;
}
const productIds = new Set(['cleanser', 'serum', 'cream', 'eye']);
const cleanText = (value: unknown, max: number) => typeof value === 'string' && value.trim().length > 0 && value.trim().length <= max && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value);

/** No client-supplied verified flag is consulted. Order evidence stays private. */
export function selectPublishableReviews(candidates: readonly ReviewCandidate[], orders: readonly TrustedOrderEvidence[]): PublicCustomerReview[] {
  const result: PublicCustomerReview[] = [];
  const seen = new Set<string>();
  for (const candidate of candidates) {
    if (!candidate || !/^[A-Za-z0-9_-]{8,100}$/.test(candidate.id) || seen.has(candidate.id)) continue;
    if (!productIds.has(candidate.productId) || candidate.publicationConsent !== true || candidate.moderationStatus !== 'approved') continue;
    if (!Number.isInteger(candidate.rating) || candidate.rating < 1 || candidate.rating > 5) continue;
    if (!cleanText(candidate.displayName, 40) || !cleanText(candidate.title, 100) || !cleanText(candidate.text, 1200)) continue;
    if (typeof candidate.createdAt !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(candidate.createdAt) || !Number.isFinite(Date.parse(candidate.createdAt))) continue;
    const matchingOrder = orders.some(order => order.orderKey === candidate.orderKey && typeof order.orderKey === 'string' && order.orderKey.length >= 16 && order.paymentStatus === 'paid' && order.fulfillmentStatus === 'fulfilled' && order.productIds.includes(candidate.productId));
    if (!matchingOrder) continue;
    seen.add(candidate.id);
    // Explicit projection prevents order IDs, customer email, address and other
    // commerce fields from leaking into the public feed.
    result.push({ id: candidate.id, productId: candidate.productId as ReviewProductId, displayName: candidate.displayName.trim(), rating: candidate.rating, title: candidate.title.trim(), text: candidate.text.trim(), createdAt: new Date(candidate.createdAt).toISOString(), verifiedPurchase: true });
  }
  return result.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 50);
}

export async function getCustomerReviewFeed() {
  // Fail closed until an authenticated real-order adapter is installed. There
  // are deliberately no seed reviews, public submission route or self-attested
  // purchase badges. Connect the actual store before replacing this snapshot.
  return { connected: false, reviews: [] as PublicCustomerReview[], count: 0, averageRating: null };
}
