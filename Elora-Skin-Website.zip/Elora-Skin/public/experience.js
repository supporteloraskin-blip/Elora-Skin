(()=>{
 'use strict';
 const navigation=document.querySelector('#navigation');
 if(!navigation)return;
 const links=[...navigation.querySelectorAll('a[href^="#"]')];
 const destinations=links.map(link=>document.getElementById(link.hash.slice(1))).filter(Boolean);
 if('IntersectionObserver' in window){
  const visible=new Map();
  const observer=new IntersectionObserver(entries=>{
   for(const entry of entries)visible.set(entry.target.id,entry.isIntersecting);
   const current=destinations.find(section=>visible.get(section.id));
   for(const link of links){if(current&&link.hash==='#'+current.id)link.setAttribute('aria-current','true');else link.removeAttribute('aria-current')}
  },{rootMargin:'-100px 0px -55% 0px',threshold:0});
  destinations.forEach(section=>observer.observe(section));
 }
})();
