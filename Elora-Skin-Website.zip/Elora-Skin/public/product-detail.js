(() => {
  'use strict';
  const dialog = document.querySelector('#product-dialog');
  const picture = document.querySelector('#dialog-product-image');
  if (!dialog || !picture) return;
  const validIds = new Set(['cleanser', 'serum', 'cream', 'eye', 'scrub', 'sunscreen', 'pads', 'toner']);
  let imageSequence = 0;
  function copyPackshot(source) {
    const clone = source.cloneNode(true);
    // Shop packshots share clipping definitions. Give every dialog copy its
    // own IDs so it cannot accidentally clip against a hidden card's SVG.
    const idMap = new Map();
    const prefix = 'dialog-packshot-' + (++imageSequence) + '-';
    for (const element of [clone, ...clone.querySelectorAll('[id]')]) {
      if (!element.id) continue;
      const oldId = element.id;
      const newId = prefix + oldId;
      idMap.set(oldId, newId);
      element.id = newId;
    }
    for (const element of [clone, ...clone.querySelectorAll('*')]) {
      for (const attribute of [...element.attributes]) {
        let value = attribute.value;
        for (const [oldId, newId] of idMap) {
          if (value === '#' + oldId) value = '#' + newId;
          value = value.replaceAll('url(#' + oldId + ')', 'url(#' + newId + ')');
        }
        if (value !== attribute.value) element.setAttribute(attribute.name, value);
      }
    }
    clone.removeAttribute('tabindex');
    clone.setAttribute('aria-hidden', 'true');
    if (clone.tagName.toLowerCase() === 'img') clone.setAttribute('alt', '');
    return clone;
  }
  document.addEventListener('click', event => {
    const trigger = event.target instanceof Element ? event.target.closest('[data-product]') : null;
    const id = trigger?.getAttribute('data-product');
    if (!validIds.has(id)) return;
    const card = document.querySelector('.shop-card[data-shop-id="' + id + '"]');
    const packshot = card?.querySelector('.product-visual .product-packshot, .product-visual img');
    const name = card?.querySelector('.shop-product-copy strong')?.textContent?.trim() || 'ELORA';
    picture.replaceChildren();
    if (packshot) picture.append(copyPackshot(packshot));
    picture.setAttribute('aria-label', name + ' packaging concept');
    dialog.dataset.productId = id;
    const planned = card?.getAttribute('data-availability') === 'planned';
    document.querySelector('#dialog-concept-status').textContent = planned ? 'In development' : 'The original collection · concept';
    const checkoutReady = document.querySelector('#checkout-button')?.disabled === false;
    const nativeStore = document.querySelector('#checkout-button')?.textContent?.includes('Continue to our store');
    document.querySelector('#dialog-commerce-state').textContent = planned
      ? 'This concept is not available to order.'
      : !checkoutReady
        ? 'Preview cart · no payment or order is created.'
        : nativeStore
          ? 'Save your selection here, then re-select it in our connected store to order.'
          : 'Add your selection here, then continue to secure checkout from the cart.';
    dialog.scrollTop = 0;
    dialog.querySelectorAll('.product-detail-accordion').forEach((accordion, index) => { accordion.open = index === 0; });
  }, true);
})();
