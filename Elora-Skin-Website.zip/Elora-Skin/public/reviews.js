(() => {
  'use strict';
  const region = document.querySelector('#customer-reviews');
  if (!region || !/^https?:$/.test(location.protocol)) return;
  const list = region.querySelector('#customer-review-list');
  const empty = region.querySelector('#customer-reviews-empty');
  const status = region.querySelector('#customer-reviews-status');
  const names = { cleanser: 'The Gentle Silk Cleanser', serum: 'Radiance Renewal Serum', cream: 'The Comfort Veil Face Cream', eye: 'The Timeless Eye Cream' };
  // Content is inserted as text, never HTML supplied by a reviewer.
  function text(tag, value, className) {
    const node = document.createElement(tag);
    node.textContent = value;
    if (className) node.className = className;
    return node;
  }
  fetch('/api/reviews', { credentials: 'same-origin', headers: { Accept: 'application/json' } })
    .then(response => response.ok ? response.json() : null)
    .then(feed => {
      if (!feed || feed.connected !== true || !Array.isArray(feed.reviews)) return;
      const reviews = feed.reviews.filter(review => review && review.verifiedPurchase === true && Object.hasOwn(names, review.productId) && typeof review.text === 'string' && typeof review.title === 'string' && typeof review.displayName === 'string' && Number.isInteger(review.rating) && review.rating >= 1 && review.rating <= 5).slice(0, 50);
      if (!reviews.length) return;
      for (const review of reviews) {
        const card = document.createElement('article');
        card.className = 'customer-review-card';
        const top = document.createElement('div');
        top.className = 'customer-review-top';
        top.append(text('p', review.displayName, 'customer-review-author'), text('span', 'Verified purchase', 'customer-review-verified'));
        const rating = text('p', '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating), 'customer-review-rating');
        rating.setAttribute('aria-label', review.rating + ' out of 5 stars');
        card.append(top, text('p', names[review.productId], 'customer-review-product'), rating, text('h3', review.title), text('p', review.text, 'customer-review-body'));
        list.append(card);
      }
      empty.hidden = true;
      list.hidden = false;
      status.textContent = reviews.length + (reviews.length === 1 ? ' customer review' : ' customer reviews');
    }).catch(() => { /* The honest empty state remains available offline. */ });
})();
