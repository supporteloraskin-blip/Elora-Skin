(() => {
  document.querySelectorAll('[data-learning-guide]').forEach(guide => {
    if (guide.dataset.learningGuideReady) return;
    guide.dataset.learningGuideReady = 'true';

    const topics = Array.from(guide.querySelectorAll('.learning-topic'));
    topics.forEach(topic => {
      topic.addEventListener('toggle', () => {
        if (!topic.open) return;
        topics.forEach(other => {
          if (other !== topic) other.open = false;
        });
      });
    });
  });
})();
