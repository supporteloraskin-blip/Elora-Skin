(()=>{
'use strict';
if(window.__eloraInitialized)return;window.__eloraInitialized=true;
// Keep one focus trap active when visitors move between support panels.
function showDialog(target){document.querySelectorAll('dialog[open]').forEach(open=>{if(open!==target)open.close()});if(!target.open)target.showModal()}
// STORE_POLICY_DATA_START
const storePolicyDraft={"status":"draft","notice":"Pre-launch draft · ordering is not open","launchNote":"These proposed ELORA SKIN terms are for review and are not yet effective. Return arrangements, shipping destinations, rates, and timing must be finalized before ordering opens.","returns":{"label":"Return policy","title":"Returns & refunds.","lead":"Thoughtful care, even when something isn’t quite right.","summary":"Our proposed return policy offers 30 days from delivery to request a return of unused, unopened, sealed products. Damaged, incorrect, or defective items are handled separately. These are draft ELORA terms; ordering is not open.","highlights":[{"value":"30 days","label":"Proposed request window"},{"value":"Unopened","label":"For change-of-mind returns"},{"value":"Contact first","label":"Before sending anything back"}],"sections":[{"id":"return-window","title":"A little room to reconsider","paragraphs":["Proposed launch policy: request a change-of-mind return within 30 calendar days after delivery. To qualify, products must be unused, unopened, in their original packaging, with any hygiene seal intact. Keep your order confirmation or other proof of purchase.","This 30-day offer is an ELORA SKIN policy proposal. It is not a return service promised by our intended manufacturer."]},{"id":"request-return","title":"Start with ELORA","paragraphs":["Contact ELORA customer care with your order number, the item you would like to return, and the reason for your request. Please wait for return approval and the correct return instructions before mailing anything.","Do not send products to a manufacturer, warehouse, or an address on a parcel without instructions from ELORA. The approved return destination will be provided with the return authorization.","Email supporteloraskin@gmail.com for customer care. Return arrangements are being finalized before orders open; this preview does not create orders or submit return requests."]},{"id":"opened-products","title":"Opened products & hygiene","paragraphs":["Under this proposed change-of-mind policy, opened, used, or unsealed skincare products are not eligible. This hygiene condition does not prevent you from reporting an incorrect, damaged, or defective item, and it does not limit rights that apply by law.","If a product causes discomfort, stop using it and seek appropriate professional advice. Contact ELORA about the product concern; we cannot promise that any formula will suit every person."]},{"id":"damaged-items","title":"Damaged, incorrect, or defective items","paragraphs":["Contact ELORA promptly if an item arrives damaged, leaking, defective, or different from what you ordered. Include your order number, a description of the issue, and clear photographs of the item and parcel where available. Keep the packaging while the issue is reviewed.","ELORA will assess the problem and explain the appropriate replacement, refund, or other remedy. You do not need to arrange a supplier claim yourself. Any approved return needed to resolve an ELORA error or confirmed defect will be handled without a return-shipping charge to you, subject to applicable rights."]},{"id":"return-costs","title":"Return shipping & costs","paragraphs":["For an approved change-of-mind return, the customer pays return shipping under the proposed policy. Original delivery charges are not refunded for a change-of-mind return, except where required by law. Any different arrangement will be explained before you send the item.","Use the shipping instructions supplied with your approval and keep your tracking or postage receipt. No restocking fee is proposed."]},{"id":"refunds","title":"Refunds & exchanges","paragraphs":["After an approved return has been received and checked, ELORA will confirm the refund decision and issue any approved refund to the original payment method. Bank and payment-provider posting times vary. The final processing timeframe will be published before launch.","Direct exchanges are not currently offered in this draft. Ask ELORA about an eligible return before placing a new order. Any legally required remedy or refund takes priority over these discretionary return terms."]},{"id":"cancellations","title":"Changes & cancellations","paragraphs":["Contact ELORA immediately if you need to change or cancel an order. Fulfillment may begin quickly, so a change or cancellation cannot be guaranteed once an order has been accepted and processing has started.","Cancellation rights and remedies for delayed or unshipped orders remain available where required by law. These proposed terms do not remove your statutory rights."]}]},"shipping":{"label":"Shipping policy","title":"Shipping, with care.","lead":"A clear journey from your ELORA ritual to your door.","summary":"Shipping destinations, costs, processing estimates, and transit estimates will be confirmed before ordering opens and shown before payment. Tracking follows dispatch. No delivery date or free-shipping offer is established in this preview.","highlights":[{"value":"Before payment","label":"See eligible destinations & costs"},{"value":"Two stages","label":"Processing, then carrier transit"},{"value":"Tracked","label":"Shipment details after dispatch"}],"sections":[{"id":"shipping-status","title":"Our store is getting ready","paragraphs":["ELORA SKIN is a pre-launch store preview. No payment is taken and no order is shipped from this preview. Selfnamed is the intended production, packing, and shipping partner through the planned Squarespace connection; that connection is not active yet.","The final launch policy will identify the available delivery services, destinations, shipping charges, and reasonable processing and transit estimates before customers pay."]},{"id":"destinations-rates","title":"Where we ship & what it costs","paragraphs":["Only destinations enabled in the live store checkout will be available. Shipping prices will be shown before payment and may depend on the destination, delivery service, and order contents. There is no confirmed free-shipping offer or worldwide-shipping promise in this draft.","International service is not confirmed. If offered at launch, any customs, duty, or import-tax arrangements will be explained before payment. Do not assume these charges are included unless checkout expressly says so."]},{"id":"processing-transit","title":"Processing time is separate from travel time","paragraphs":["Order processing covers payment confirmation and preparing the items for dispatch. Carrier transit begins after the parcel is handed to the delivery service. Adding a processing estimate to a transit estimate gives the expected overall journey.","ELORA-specific times have not been confirmed, so this draft does not promise same-day dispatch or a delivery date. When the store opens, supported estimates will be displayed before payment. Any express delivery commitment will be identified clearly."]},{"id":"tracking","title":"Follow your parcel","paragraphs":["When the native store and fulfillment connection is active, shipment confirmation and available tracking details will be sent through the store after dispatch. Tracking can take time to show its first carrier scan.","If an order is split into separate parcels, each shipment may have its own tracking information. Contact ELORA if a dispatch notice is missing or tracking appears stuck; chat cannot look up or change orders."]},{"id":"address-details","title":"Check your delivery details","paragraphs":["Before paying, check the recipient’s name, full street address, apartment or unit details, postal code, email, and phone number. Delivery services may need these details to complete delivery.","Contact ELORA immediately if an address is wrong. Corrections or cancellations may be unavailable once processing begins. If a parcel is returned or delivery fails, ELORA will explain the options and any applicable redelivery cost before requesting further payment."]},{"id":"delays-missing","title":"Delays, missing parcels & delivery problems","paragraphs":["If ELORA cannot meet the stated shipment timeframe, we will notify you and offer the choice to agree to the delay or cancel the unshipped items for a prompt refund, as applicable law requires. An estimate is not a waiver of your rights.","For a parcel marked delivered that you cannot find, check the tracking information and any safe delivery location, then contact ELORA promptly. Keep the order number and relevant delivery information. ELORA will coordinate an investigation and explain the appropriate remedy; the issue is not automatically your responsibility."]},{"id":"shipping-damage","title":"Something arrived damaged?","paragraphs":["Contact ELORA promptly with your order number, a description, and photographs of the item and outer packaging where available. Keep the parcel and its contents while we review the issue.","See the Return policy for damaged, incorrect, or defective items. Do not mail an item back until ELORA provides return instructions. Contact customer care at supporteloraskin@gmail.com."]}]}};
// STORE_POLICY_DATA_END
// RITUAL_QUIZ_DATA_START
const quizQuestions=[{"id":"feel","label":"YOUR EVERYDAY FEEL","title":"How does your skin usually feel?","hint":"Choose what feels closest. Your skin can change with the season.","options":[{"value":"dry","label":"Dry or tight","detail":"I often notice a dry or tight feeling."},{"value":"shiny","label":"Shiny","detail":"I tend to notice shine across my face."},{"value":"mixed","label":"Different in different areas","detail":"Some areas feel dry; others look shiny."},{"value":"balanced","label":"Comfortable and balanced","detail":"Usually neither especially dry nor shiny."},{"value":"unsure","label":"I’m not sure","detail":"I’d rather keep the starting point simple."}]},{"id":"response","label":"YOUR COMFORT","title":"How do new products usually feel?","hint":"This is about your experience, not a medical assessment.","options":[{"value":"reactive","label":"My skin is easily unsettled","detail":"New products can feel uncomfortable."},{"value":"comfortable","label":"Usually comfortable","detail":"I do not often notice discomfort."},{"value":"unsure","label":"It varies, or I’m unsure","detail":"I’d like a cautious starting point."}]},{"id":"goal","label":"YOUR INTENTION","title":"What would you like your ritual to focus on?","hint":"Pick the intention that feels most like you.","options":[{"value":"comfort","label":"A comfortable feel","detail":"Make care a little moment of comfort."},{"value":"radiance","label":"A radiant-looking finish","detail":"Explore the botanical facial-oil direction."},{"value":"simple","label":"A simple, steady habit","detail":"Make a little room for myself each day."}]},{"id":"pace","label":"YOUR PACE","title":"How much room is there in your routine?","hint":"More steps are optional. A small ritual can be enough.","options":[{"value":"simple","label":"Keep it simple","detail":"Two core concepts to explore."},{"value":"extra","label":"Room for an optional extra","detail":"I’m interested in one additional concept."}]},{"id":"moment","label":"YOUR MOMENT","title":"When is your ELORA moment?","hint":"Choose the rhythm you would like to make your own.","options":[{"value":"morning","label":"Morning light","detail":"A quiet beginning before the day."},{"value":"evening","label":"Evening calm","detail":"A pause as the day winds down."},{"value":"both","label":"A little of both","detail":"A moment at the beginning and end."}]}];
const buildQuizResult=function buildQuizResult(answers) {
  if (!answers || typeof answers !== 'object' || Array.isArray(answers)) return null;
  for (const question of quizQuestions) {
    if (!Object.hasOwn(answers,question.id) || !question.options.some(option=>option.value===answers[question.id])) return null;
  }
  const cautious = answers.response !== 'comfortable';
  const serum = !cautious && answers.goal === 'radiance' && answers.pace === 'extra';
  const productIds = serum ? ['cleanser','serum','cream'] : ['cleanser','cream'];
  const title = cautious ? 'A quieter place to begin.' : answers.goal === 'comfort' ? 'A ritual for comfort.' : serum ? 'A little room for radiance.' : 'The beauty of keeping it simple.';
  const summary = cautious ? 'You preferred a cautious starting point. Explore two core ingredient directions, with optional extras left out.' : serum ? 'You chose a radiant-looking finish and space for an extra step. Explore the cleanser and cream concepts, with the facial-oil serum as an optional chapter.' : 'Your answers point toward a small, steady ritual. Explore the cleanser and cream ingredient directions before adding extra steps.';
  const reasons = {
    cleanser:'Explore the proposed gentle-cleansing direction: aloe, sunflower, and jojoba. The finished cleansing system and tolerability are still unverified.',
    cream:answers.goal==='comfort'||answers.feel==='dry' ? 'Your preference for comfort makes the proposed shea, aloe, and sunflower direction worth exploring. This is not a verified match for dry or sensitive skin.' : 'Explore the proposed moisturizing direction alongside cleansing. Texture, complete ingredients, and suitability still need confirmation.',
    serum:'An optional botanical facial-oil concept with jojoba, rosehip, and sunflower. It is not verified as suitable for your skin or as noncomedogenic.'
  };
  const notes = [
    'These are ingredient concepts to explore, not a diagnosis or a tested product match. Every finished formula and skin-type claim still needs verification.',
    cautious ? 'Because you reported discomfort or uncertainty, keep the exploration minimal. Organic ingredients can still irritate; a dermatologist can help if you are unsure what to use.' : 'Before trying a finished product, check its final ingredient list and directions. A comfortable history with other products does not guarantee a new product will suit you.'
  ];
  return { title, summary, productIds, reasons, cautious,
    chips:quizQuestions.filter(q=>['goal','pace','moment'].includes(q.id)).map(q=>q.options.find(o=>o.value===answers[q.id]).label),
    notes,
    sunCare:answers.moment!=='evening' ? 'For daytime, include a tested broad-spectrum SPF 30 or higher sunscreen. ELORA’s sunscreen remains an untested concept and cannot provide sun protection.' : null
  };
};
// RITUAL_QUIZ_DATA_END
const packagingConcepts={"cleanser":"Pump bottle","serum":"Dropper bottle","cream":"Cream jar","eye":"Airless pump bottle","scrub":"Cream jar","sunscreen":"Squeeze tube","pads":"Upright flip-top dispenser","toner":"Fine-mist sprayer"};
const products={
 cleanser:{kicker:'01 / A FRESH BEGINNING',name:'The Gentle Silk Cleanser',description:"Meet The Gentle Silk Cleanser by ELORA SKIN. An organic-first cleanser concept, developed with melanin-rich skin in mind and a gentle, comfortable cleansing experience as the goal. Every skin tone is welcome; the final formula and skin-type suitability still need verification."},
 serum:{kicker:'02 / A MOMENT TO RENEW',name:'Radiance Renewal Serum',description:"Meet Radiance Renewal Serum by ELORA SKIN. A proposed blend of organic jojoba, rosehip, and sunflower oils, envisioned for a supple, radiant-looking finish that celebrates your natural complexion. The finished blend, performance, and skin-type suitability still need testing."},
 cream:{kicker:'03 / AN EVERYDAY COMFORT',name:'The Comfort Veil Face Cream',description:"Meet The Comfort Veil Face Cream by ELORA SKIN. An organic-first moisturizing concept built around shea butter, aloe, and sunflower oil, with skin comfort and hydration as formulation goals. Created with melanin-rich skin in mind; final suitability must be verified for each intended skin type."},
 eye:{kicker:'04 / THE FINISHING TOUCH',name:'The Timeless Eye Cream',description:"Meet The Timeless Eye Cream by ELORA SKIN. An organic-first eye-area concept featuring jojoba, shea, and aloe, with a comfortable daily ritual as the goal. The complete formula needs specialist eye-area testing and verified directions before use."},
 scrub:{"kicker": "05 / A GENTLER APPROACH", "name": "Gentle Facial Scrub", "description": "A low-abrasion facial-scrub concept with melanin-rich skin in mind. Organic-grade oat, aloe, and jojoba are proposed starting points. The final exfoliation system, skin-type suitability, and frequency still need specialist assessment.", "price": null, "size": "Size to be confirmed", "availability": "planned"},
 sunscreen:{"kicker": "06 / SUN CARE, CONSIDERED", "name": "Sunscreen", "description": "A future sunscreen concept with melanin-rich skin in mind. Organic-grade botanicals are being considered for supporting ingredients. The UV filters, SPF, broad-spectrum performance, finish, and skin-type suitability have not been established. This concept is not an available sun-protection product.", "price": null, "size": "Size to be confirmed", "availability": "planned"},
 pads:{"kicker": "07 / A SIMPLE DAILY PAUSE", "name": "Cleansing Facial Pads", "description": "Soft cleansing facial pads are the goal for this upcoming concept. Aloe and sunflower are proposed botanical starting points for the cleansing solution. Pad material, the complete solution, preservation, and skin-type suitability still need testing.", "price": null, "size": "Size to be confirmed", "availability": "planned"},
 toner:{"kicker": "08 / A MOMENT TO RESET", "name": "Facial Toner", "description": "An aloe-led facial toner concept in a fine-mist facial spray bottle, envisioned without added fragrance or essential oils. The packaging pairs an ivory body with an olive-green mist sprayer and warm gold collar. The complete formula, pH, preservation, directions, sprayer compatibility, and suitability across skin types still need manufacturer verification.", "price": null, "size": "Size to be confirmed", "availability": "planned"}
};
// INGREDIENT_DATA_START
const ingredientConcepts={"status":"proposed","organicProductCertification":"unverified","sourcingGoal":"Source certified-organic grades of every proposed botanical. Finished-product organic certification is a development goal, not a verified product claim. The manufacturer must verify the complete formula, processing, suppliers, and certification eligibility.","fragranceDirection":"No added fragrance or essential oils proposed at this stage. This is a design direction, not a verified finished-product claim.","botanicals":{"aloe":{"name":"Aloe vera","kind":"Leaf-based botanical","sourcing":"Certified-organic cosmetic-grade aloe; the manufacturer must confirm the exact juice or powder grade and label name."},"sunflower":{"name":"Sunflower seed oil","kind":"Seed oil","sourcing":"Certified-organic cosmetic-grade sunflower seed oil, with supplier documentation and batch specifications."},"jojoba":{"name":"Jojoba seed oil","kind":"Seed oil","sourcing":"Certified-organic cosmetic-grade jojoba seed oil, with supplier documentation and batch specifications."},"rosehip":{"name":"Rosehip seed oil","kind":"Seed oil","sourcing":"Certified-organic cosmetic-grade rosehip seed oil; confirm the botanical species, grade, and exact label name."},"shea":{"name":"Shea butter","kind":"Plant butter","sourcing":"Certified-organic cosmetic-grade shea butter; the manufacturer must select the grade and verify supplier documentation."},"oat":{"name":"Oat kernel flour","kind":"Cosmetic-grade botanical","sourcing":"Explore a certified-organic cosmetic grade. Particle shape, size, abrasive properties, preservation, and skin tolerability must be assessed by the formulator."}},"products":{"cleanser":{"name":"The Gentle Silk Cleanser","number":"01","direction":"A gentle-cleansing concept with melanin-rich skin in mind","ingredients":["aloe","sunflower","jojoba"],"developmentNote":"A cosmetic formulator will need to design the complete cleansing system, preservation, pH, and final ingredient label. Assess tolerability across skin tones and intended skin types, including melanin-rich skin, before making suitability or performance claims."},"serum":{"name":"Radiance Renewal Serum","number":"02","direction":"A botanical facial-oil concept for a radiant-looking finish","ingredients":["jojoba","rosehip","sunflower"],"developmentNote":"The manufacturer will need to assess the complete blend, oxidation stability, packaging compatibility, and final ingredient label. Assess tolerability across skin tones and intended skin types, including melanin-rich skin, before making suitability or performance claims."},"cream":{"name":"The Comfort Veil Face Cream","number":"03","direction":"A comfort-focused moisturizing cream concept","ingredients":["shea","aloe","sunflower"],"developmentNote":"A cosmetic formulator will need to finalize the emulsion, preservation, pH, stability, and complete ingredient label. Assess tolerability across skin tones and intended skin types, including melanin-rich skin, before making suitability or performance claims."},"eye":{"name":"The Timeless Eye Cream","number":"04","direction":"An eye-area comfort concept for specialist testing","ingredients":["jojoba","shea","aloe"],"developmentNote":"The complete formula and packaging need a specific eye-area suitability assessment, effective preservation, stability checks, and a verified final ingredient label. Assess tolerability across skin tones and intended skin types, including melanin-rich skin, before making suitability or performance claims."},"scrub":{"name":"Gentle Facial Scrub","number":"05","direction":"A low-abrasion facial-scrub concept for specialist review","ingredients":["oat","aloe","jojoba"],"developmentNote":"The formulator must determine whether a scrub is appropriate for the intended audience, assess particle shape and size, set directions and frequency, and test the finished formula. Scrubs may be unsuitable for sensitive, inflamed, or acne-prone skin. No all-skin-types claim is verified.","availability":"planned"},"sunscreen":{"name":"Sunscreen","number":"06","direction":"A sunscreen concept awaiting UV-filter selection and SPF testing","ingredients":["aloe","sunflower"],"developmentNote":"A qualified sunscreen manufacturer must select appropriate UV filters, complete SPF and broad-spectrum testing, assess stability and skin tolerability, and finalize labeling. No SPF, broad-spectrum, water-resistance, no-white-cast, or all-skin-types claim is established. Botanical ingredients do not replace tested UV filters; organic botanical sourcing does not establish sun protection.","availability":"planned"},"pads":{"name":"Cleansing Facial Pads","number":"07","direction":"A soft cleansing-pad concept with a non-exfoliating brief","ingredients":["aloe","sunflower"],"developmentNote":"The manufacturer must select the pad material and complete cleansing solution, and assess preservation, packaging, stability, residue, and skin tolerability. Organic-grade botanicals are a sourcing goal; pad material and finished-product certification must be verified separately. No exfoliating-acid or all-skin-types claim is established.","availability":"planned"},"toner":{"name":"Facial Toner","number":"08","direction":"An aloe-led fine-mist facial-toner concept without added fragrance","ingredients":["aloe"],"developmentNote":"A cosmetic formulator must select the full water-based system, humectants, preservation, and pH, then verify stability and tolerability across intended skin types. The packaging concept uses a fine-mist facial sprayer; the manufacturer must confirm the final sprayer, formula compatibility, and directions. No astringent, alcohol-free, pore-tightening, or all-skin-types claim is established.","availability":"planned"}},"references":[{"title":"USDA: Cosmetics, Body Care, and Personal Care Products","url":"https://www.ams.usda.gov/grades-standards/cosmetics-body-care-and-personal-care-products"},{"title":"FDA: Organic Cosmetics","url":"https://www.fda.gov/cosmetics/cosmetics-labeling-claims/organic-cosmetics"},{"title":"FDA: Microbiological Safety and Cosmetics","url":"https://www.fda.gov/cosmetics/potential-contaminants-cosmetics/microbiological-safety-and-cosmetics"},{"title":"AAD: Gentle care and dark spots in darker skin tones","url":"https://www.aad.org/public/everyday-care/skin-care-secrets/routine/fade-dark-spots"},{"title":"FDA: Sunscreen labeling and effectiveness testing","url":"https://www.fda.gov/regulatory-information/search-fda-guidance-documents/labeling-and-effectiveness-testing-sunscreen-drug-products-over-counter-human-use-small-entity"},{"title":"AAD: How to safely exfoliate at home","url":"https://www.aad.org/public/everyday-care/skin-care-secrets/routine/safely-exfoliate-at-home"}],"rawMaterialExamples":[{"title":"Praan Naturals organic jojoba specification","url":"https://www.praannaturals.com/downloads/specsheets/SPEC-Organic-Jojoba-Oil-Natural-ORGOILJOJONATEXPIL851.pdf"},{"title":"Praan Naturals raw-material product list","url":"https://www.praannaturals.com/downloads/NS_product_listv7.pdf/"},{"title":"Jedwards organic rosehip oil","url":"https://bulknaturaloils.com/rosehip-oil-virgin-organic-s1520.html"}],"positioning":"Melanin-rich skin at the heart. Every skin tone welcome.","skinTypesGoal":"Develop the collection with dry, oily, combination, and sensitive skin in mind. Suitability must be established for each finished product. A scrub may not suit every skin type, and no formula can be guaranteed suitable for every person.","formulationGoals":["Prioritize gentle cleansing, hydration, and skin comfort in the formulation brief.","Propose no added fragrance, essential oils, harsh scrubs, or skin-bleaching ingredients.","Evaluate tolerability across skin tones and skin types, including melanin-rich skin.","Select certified-organic botanical grades and verify any finished-product organic claim."]};
// INGREDIENT_DATA_END
const money=amount=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(amount/100);
Object.assign(products.cleanser,{price:1600,size:'120 mL'});Object.assign(products.serum,{price:2200,size:'30 mL'});Object.assign(products.cream,{price:2300,size:'50 mL'});Object.assign(products.eye,{price:1800,size:'15 mL'});
const availableIds=['cleanser','serum','cream','eye'];
const previewBundles={
 'all-eight':{name:'The All Eight Essentials Bundle',kicker:'ONE OF EACH · 8 PRODUCTS',price:16900,contents:['cleanser','serum','cream','eye','scrub','sunscreen','pads','toner']}
};
const cartProducts={...products,...previewBundles};
const cartIds=[...availableIds,...Object.keys(previewBundles)];
const menu=document.querySelector('.menu-toggle');
const nav=document.querySelector('#navigation');
menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Close navigation':'Open navigation');nav.classList.toggle('open',open)});
nav.addEventListener('click',e=>{if(e.target.closest('a')){menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Open navigation');nav.classList.remove('open')}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('open')){nav.classList.remove('open');menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Open navigation');menu.focus()}});
const dialog=document.querySelector('#product-dialog');
let activeProduct=null;
document.querySelectorAll('[data-product]').forEach(button=>button.addEventListener('click',()=>{activeProduct=button.dataset.product;const p=products[activeProduct];document.querySelector('#dialog-kicker').textContent=p.kicker;document.querySelector('#dialog-title').textContent=p.name;document.querySelector('#dialog-description').textContent=p.description;document.querySelector('#dialog-packaging').textContent='PACKAGING CONCEPT · '+packagingConcepts[activeProduct];document.querySelector('#dialog-price').textContent=p.availability==='planned'?'IN DEVELOPMENT · PACKAGING CONCEPT':money(p.price)+' · '+p.size+' · Proposed size & price';configureDialogAdd();document.querySelector('.dialog-note p').textContent=p.availability==='planned'?'This product is in development. Price, size, finished formula, and suitability are not finalized.':'Online shopping is coming soon. Ingredient lists, directions, and confirmed prices will be available with the shop.';renderIngredientConcept(activeProduct);showDialog(dialog)}));
document.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());
dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close()}});
document.querySelector('#dialog-ritual').addEventListener('click',()=>dialog.close());
document.querySelector('#dialog-ingredients-link').addEventListener('click',()=>dialog.close());
function configureDialogAdd(){const planned=products[activeProduct]?.availability==='planned';document.querySelector('#dialog-add').disabled=planned;document.querySelector('#dialog-add').textContent=planned?'In development':'Add to cart ＋';document.querySelector('#dialog-add').setAttribute('aria-label',planned?products[activeProduct].name+' is in development':'Add '+products[activeProduct].name+' to cart');}
function renderIngredientConcept(id){const concept=ingredientConcepts.products[id];document.querySelector('#dialog-development-note').textContent=concept.developmentNote;const list=document.querySelector('#dialog-ingredient-list');list.replaceChildren();document.querySelector('#dialog-ingredients-title').textContent=concept.direction;for(const key of concept.ingredients){const item=document.createElement('li');item.textContent=ingredientConcepts.botanicals[key].name;list.append(item);}document.querySelector('#dialog-ingredients-link').href='#ingredients-'+id;}

// Morning and evening planning is owned by ritual-guide.js.
document.querySelector('#year').textContent=String(new Date().getFullYear());

// Populate only verified business contact details. No contact form sends data.
const brandContact={email:'supporteloraskin@gmail.com',phone:null,tiktok:'https://www.tiktok.com/@eloraskin5',instagram:'https://www.instagram.com/eloraskincare52/'};
if(brandContact.email){const link=document.querySelector('#contact-email');link.textContent=brandContact.email;link.href='mailto:'+brandContact.email;link.hidden=false;document.querySelector('#contact-email-pending').hidden=true}
if(brandContact.phone){const link=document.querySelector('#contact-phone');link.textContent=brandContact.phone;link.href='tel:'+brandContact.phone.replace(/[^+\d]/g,'');link.hidden=false}
for(const network of ['tiktok','instagram'])document.querySelectorAll('[data-social="'+network+'"]').forEach(link=>{link.href=brandContact[network]});

const cartKey='elora-cart-v1';
const maxQuantity=20;
let cart={};
let cartStorageAvailable=true;
let checkoutAvailable=false;
let checkoutLabel='Checkout coming soon ↗';
let checkoutNote=document.querySelector('#cart-checkout-note').textContent;
const cartDialog=document.querySelector('#cart-dialog');
const cartStatus=document.querySelector('#cart-status');
const cartList=document.querySelector('#cart-items');
const toast=document.querySelector('#cart-toast');
let toastTimer;
function readCart(raw){
  const result={};
  try{const value=JSON.parse(raw);if(value&&typeof value==='object'&&!Array.isArray(value))for(const id of cartIds){const q=value[id];if(Number.isInteger(q)&&q>0)result[id]=Math.min(q,maxQuantity)}}catch{}
  return result;
}
try{cart=readCart(localStorage.getItem(cartKey))}catch{cartStorageAvailable=false}
function cartCount(){return Object.values(cart).reduce((sum,q)=>sum+q,0)}
function cartElement(tag,className,text){const el=document.createElement(tag);if(className)el.className=className;if(text!==undefined)el.textContent=text;return el}
function persistCart(){try{localStorage.setItem(cartKey,JSON.stringify(cart));cartStorageAvailable=true}catch{cartStorageAvailable=false}}
function hasPreviewBundle(){return Object.keys(cart).some(id=>Object.hasOwn(previewBundles,id))}
function syncCartCheckout(){
 const bundle=hasPreviewBundle();
 const button=document.querySelector('#checkout-button');
 button.disabled=!checkoutAvailable||bundle||cartCount()===0;
 button.textContent=bundle?'Bundle coming soon':checkoutLabel;
 document.querySelector('#cart-checkout-note').textContent=bundle?'The eight-product bundle is a proposed $169.00 before shipping and tax. Final products, supplier costs, and availability are being confirmed. Save or copy your selections; no order or payment is made.':checkoutNote;
}
function renderCart(){
  const count=cartCount();
  document.querySelector('#cart-count').textContent=String(count);
  document.querySelector('#open-cart').setAttribute('aria-label',`Open cart, ${count} ${count===1?'item':'items'}`);
  document.querySelector('#cart-empty').hidden=count>0;
  document.querySelector('#cart-summary').hidden=count===0;
  document.querySelector('#cart-item-total').textContent=`${count} ${count===1?'item':'items'}`;
  document.querySelector('#cart-subtotal').textContent=money(Object.entries(cart).reduce((sum,[id,q])=>sum+cartProducts[id].price*q,0));
  document.querySelector('#cart-copy-fallback').hidden=true;
  cartList.replaceChildren();
  for(const [id,quantity] of Object.entries(cart)){
    const product=cartProducts[id];
    const item=cartElement('li','cart-item');
    const info=cartElement('div','cart-item-info');
    info.append(cartElement('p','eyebrow',product.kicker),cartElement('h3','',product.name),cartElement('p','cart-item-price',money(product.price)+' each · Proposed price'));
    if(product.contents)info.append(cartElement('p','cart-item-contents','One of each: '+product.contents.map(key=>products[key].name).join(', ')+'.'));
    const controls=cartElement('div','cart-item-controls');
    const quantityControl=cartElement('div','quantity-control');
    quantityControl.setAttribute('role','group');quantityControl.setAttribute('aria-label','Quantity for '+product.name);
    for(const [action,label,glyph,disabled] of [['decrease','Decrease quantity of ','−',quantity===1],['increase','Increase quantity of ','+',quantity===maxQuantity]]){
      const button=cartElement('button','',glyph);button.type='button';button.dataset.cartAction=action;button.dataset.id=id;button.setAttribute('aria-label',label+product.name);button.disabled=disabled;
      if(action==='increase')quantityControl.append(cartElement('span','quantity-value',String(quantity)));
      quantityControl.append(button);
    }
    const remove=cartElement('button','remove-cart-item','Remove');remove.type='button';remove.dataset.cartAction='remove';remove.dataset.id=id;remove.setAttribute('aria-label','Remove '+product.name+' from cart');
    controls.append(quantityControl,remove);item.append(info,controls);cartList.append(item);
  }
  if(!cartStorageAvailable)cartStatus.textContent='Your cart works for this visit. This browser could not save it for later.';
  syncCartCheckout();
}
function showCart(){if(dialog.open)dialog.close();toast.hidden=true;clearTimeout(toastTimer);cartStatus.textContent='';renderCart();if(!cartDialog.open)showDialog(cartDialog)}
function addToCart(id){
  if(!cartIds.includes(id))return;
  if((cart[id]||0)>=maxQuantity){cartStatus.textContent='You can save up to 20 of each product.';document.querySelector('#cart-toast-text').textContent='You’ve saved the maximum quantity of this product.'}
  else{cart[id]=(cart[id]||0)+1;persistCart();renderCart();document.querySelector('#cart-toast-text').textContent=cartProducts[id].name+' added to your cart.'}
  toast.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{if(!toast.matches(':focus-within'))toast.hidden=true},6000);
  if(dialog.open){document.querySelector('#dialog-add').textContent='Added to cart ✓';setTimeout(configureDialogAdd,1800)}
}
document.querySelectorAll('[data-add]').forEach(button=>button.addEventListener('click',()=>addToCart(button.dataset.add)));
document.querySelectorAll('[data-add-bundle]').forEach(button=>button.addEventListener('click',()=>{addToCart(button.dataset.addBundle);showCart();cartStatus.textContent='Eight-product bundle saved at a proposed $169.00 before shipping and tax. No order has been placed.'}));
document.querySelector('#dialog-add').addEventListener('click',()=>{const id=activeProduct;if(!availableIds.includes(id))return;const previous=cart[id]||0;addToCart(id);showCart();cartStatus.textContent=(cart[id]||0)>previous?products[id].name+' added. Your selections are a preview; no order has been placed.':'You can save up to 20 of each product. Your selections are a preview; no order has been placed.';});
document.querySelector('#open-cart').addEventListener('click',showCart);
document.querySelector('#toast-view-cart').addEventListener('click',showCart);
document.querySelector('#close-cart').addEventListener('click',()=>cartDialog.close());
for(const id of ['cart-explore','cart-contact'])document.querySelector('#'+id).addEventListener('click',()=>cartDialog.close());
cartDialog.addEventListener('click',e=>{if(e.target===cartDialog){const r=cartDialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)cartDialog.close()}});
cartList.addEventListener('click',e=>{
  const button=e.target.closest('[data-cart-action]');if(!button)return;
  const id=button.dataset.id;const action=button.dataset.cartAction;if(!Object.hasOwn(cart,id))return;
  if(action==='remove')delete cart[id];
  else cart[id]=Math.max(1,Math.min(maxQuantity,cart[id]+(action==='increase'?1:-1)));
  persistCart();renderCart();cartStatus.textContent=action==='remove'?cartProducts[id].name+' removed.':'Cart updated.';
  const next=[...cartList.querySelectorAll('[data-cart-action]')].find(b=>b.dataset.id===id&&b.dataset.cartAction===action&&!b.disabled)||cartList.querySelector('button:not(:disabled)')||document.querySelector('#cart-explore');next.focus();
});
document.querySelector('#clear-cart').addEventListener('click',()=>{cart={};persistCart();renderCart();cartStatus.textContent='Your cart has been cleared.';document.querySelector('#cart-explore').focus()});
document.querySelector('#copy-cart').addEventListener('click',async()=>{
  const summary='My ELORA SKIN selections\n\n'+Object.entries(cart).map(([id,q])=>`${q} × ${cartProducts[id].name}`+(cartProducts[id].contents?'\n  One of each: '+cartProducts[id].contents.map(key=>products[key].name).join(', '):'')).join('\n')+'\n\nProposed subtotal: '+money(Object.entries(cart).reduce((sum,[id,q])=>sum+cartProducts[id].price*q,0))+'\nShipping and tax are additional. Final products, supplier costs, and availability are being confirmed.\nPreview only — no order has been placed.';
  try{await navigator.clipboard.writeText(summary);cartStatus.textContent='Your selections have been copied.'}
  catch{const field=document.querySelector('#cart-copy-fallback');field.value=summary;field.hidden=false;field.focus();field.select();cartStatus.textContent='Your selections are ready below. Use your device’s copy command.'}
});
window.addEventListener('storage',e=>{if(e.key===cartKey){cart=readCart(e.newValue);renderCart()}});
renderCart();

// Shopping controls and favorites.
let activeFilter='all';
let favoriteIds=[];
try{const value=JSON.parse(localStorage.getItem('elora-favorites')||'[]');if(Array.isArray(value))favoriteIds=[...new Set(value.filter(id=>Object.hasOwn(products,id)))]}catch{}
const membershipStatus=document.querySelector('#membership-status');
const favoriteStatus=document.createElement('p');favoriteStatus.id='favorite-status';favoriteStatus.className='sr-only';favoriteStatus.setAttribute('role','status');favoriteStatus.setAttribute('aria-live','polite');document.querySelector('.shop-search').after(favoriteStatus);
function filterShop(){
 const query=document.querySelector('#product-search').value.trim().toLowerCase();let visible=0;
 document.querySelectorAll('[data-shop-id]').forEach(card=>{const id=card.dataset.shopId;const category=activeFilter==='all'||(activeFilter==='favorites'?favoriteIds.includes(id):activeFilter==='upcoming'?products[id].availability==='planned':card.dataset.category===activeFilter);const match=category&&products[id].name.toLowerCase().includes(query);card.hidden=!match;if(match)visible++;});
 document.querySelector('#shop-result-count').textContent=visible+' '+(visible===1?'product':'products');document.querySelector('#shop-no-results').hidden=visible!==0;
}
function refreshFavorites(){document.querySelectorAll('[data-favorite]').forEach(button=>{const active=favoriteIds.includes(button.dataset.favorite);button.setAttribute('aria-pressed',String(active));button.textContent=active?'♥':'♡';button.setAttribute('aria-label',(active?'Remove ':'Save ')+products[button.dataset.favorite].name+(active?' from favorites':' to favorites'));});filterShop()}
function saveFavorites(){try{localStorage.setItem('elora-favorites',JSON.stringify(favoriteIds));return true}catch{return false}}
 document.querySelectorAll('[data-favorite]').forEach(button=>button.addEventListener('click',()=>{const id=button.dataset.favorite;favoriteIds=favoriteIds.includes(id)?favoriteIds.filter(x=>x!==id):[...favoriteIds,id];refreshFavorites();const persisted=saveFavorites();favoriteStatus.textContent=products[id].name+(favoriteIds.includes(id)?' added to favorites.':' removed from favorites.')+(persisted?' Saved in this browser.':' This change applies for this visit; this browser could not save it for later.');if(button.closest('[data-shop-id]').hidden){const next=document.querySelector('[data-shop-id]:not([hidden]) [data-favorite]')||document.querySelector('[data-filter="favorites"]');next.focus();}}));
 document.querySelectorAll('[data-filter]').forEach(button=>button.addEventListener('click',()=>{activeFilter=button.dataset.filter;document.querySelectorAll('[data-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));filterShop()}));
 document.querySelector('#product-search').addEventListener('input',filterShop);
document.querySelector('#reset-shop').addEventListener('click',()=>{document.querySelector('#product-search').value='';activeFilter='all';document.querySelectorAll('[data-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.filter==='all')));filterShop();document.querySelector('#product-search').focus();});
 document.querySelector('#shop-sort').addEventListener('change',e=>{const ids=Object.keys(products);const cards=[...document.querySelectorAll('[data-shop-id]')];cards.sort((a,b)=>{const pa=products[a.dataset.shopId],pb=products[b.dataset.shopId];const phase=Number(pa.availability==='planned')-Number(pb.availability==='planned');if(phase)return phase;if(e.target.value==='ritual')return ids.indexOf(a.dataset.shopId)-ids.indexOf(b.dataset.shopId);return((pa.price??0)-(pb.price??0))*(e.target.value==='high'?-1:1)});document.querySelector('#shop-grid').append(...cards)});
 document.querySelector('#add-full-ritual').addEventListener('click',()=>{for(const id of availableIds)cart[id]=Math.min(maxQuantity,(cart[id]||0)+1);persistCart();renderCart();showCart()});
refreshFavorites();

// Digital cards are local to this browser and need no account.
const card=document.querySelector('#member-card');
const memberName=document.querySelector('#member-name');
const cardKey='elora-card-v1';
let cardStyle='olive';
let localCard=null;
let cardSavedInBrowser=false;
try{const stored=JSON.parse(localStorage.getItem(cardKey)||'null');if(stored&&typeof stored.name==='string'&&stored.name.trim()&&stored.name.length<=45&&['olive','ivory'].includes(stored.style)){localCard={name:stored.name,style:stored.style};cardSavedInBrowser=true;memberName.value=stored.name;cardStyle=stored.style;}}catch{}
function fitCardPreview(){const label=document.querySelector('#card-name');label.style.fontSize='';const style=getComputedStyle(label);const measure=document.createElement('canvas').getContext('2d');if(!measure)return;measure.font=style.fontSize+' '+style.fontFamily;const width=measure.measureText(label.textContent).width;const available=label.clientWidth;if(available>0&&width>available)label.style.fontSize=(parseFloat(style.fontSize)*available/width*.98)+'px';}
function updateCard(announceChanges=false){const draftName=memberName.value.trim();const name=draftName||'Your name';const matchesSaved=!!localCard&&localCard.name.trim()===draftName&&localCard.style===cardStyle;document.querySelector('#card-name').textContent=name;document.querySelector('#card-number').textContent=matchesSaved?'DIGITAL CARD':localCard?'UNSAVED CHANGES':'CARD PREVIEW';card.classList.toggle('ivory',cardStyle==='ivory');card.classList.toggle('olive',cardStyle==='olive');card.setAttribute('aria-label','ELORA Circle digital card for '+name);document.querySelectorAll('[data-card-style]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.cardStyle===cardStyle)));document.querySelector('#clear-saved-card').hidden=!localCard;if(announceChanges)membershipStatus.textContent=localCard&&!matchesSaved?'You have unsaved changes. Save or download this version to keep it.':matchesSaved?(cardSavedInBrowser?'This design matches your saved card.':'This design is ready for this visit. Download a copy to keep.') :'';fitCardPreview();}
memberName.addEventListener('input',()=>updateCard(true));
document.querySelectorAll('[data-card-style]').forEach(button=>button.addEventListener('click',()=>{cardStyle=button.dataset.cardStyle;updateCard(true)}));
function saveLocalCard(){if(!memberName.value.trim()){memberName.setCustomValidity('Enter the name you want on your card.');memberName.reportValidity();memberName.setCustomValidity('');return false;}localCard={name:memberName.value.trim(),style:cardStyle};try{localStorage.setItem(cardKey,JSON.stringify(localCard));cardSavedInBrowser=true;membershipStatus.textContent='Your card is saved in this browser. Download a copy to keep.';}catch{cardSavedInBrowser=false;membershipStatus.textContent='Your card is ready for this visit. Download a copy to keep.';}updateCard();return true;}
document.querySelector('#member-form').addEventListener('submit',e=>{e.preventDefault();saveLocalCard()});
document.querySelector('#clear-saved-card').addEventListener('click',()=>{try{localStorage.removeItem(cardKey)}catch{membershipStatus.textContent='This browser could not clear your saved card. Clear site data in your browser settings.';return;}localCard=null;cardSavedInBrowser=false;memberName.value='';cardStyle='olive';updateCard();membershipStatus.textContent='Your saved card has been cleared from this browser.';});
updateCard();
if(typeof ResizeObserver!=='undefined')new ResizeObserver(fitCardPreview).observe(card);else window.addEventListener('resize',fitCardPreview);
function escapeXml(text){return String(text).replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]));}
function cardSvg(){const light=cardStyle==='ivory';const bg=light?'#f5f1e7':'#52634e';const ink=light?'#52634e':'#f5f1e7';const rawName=memberName.value.trim()||'YOUR NAME';const name=escapeXml(rawName);const measure=document.createElement('canvas').getContext('2d');let nameWidth=Infinity;if(measure){measure.font='44px Georgia,serif';nameWidth=measure.measureText(rawName).width;}const fittedName=nameWidth>720?' textLength="720" lengthAdjust="spacingAndGlyphs"':'';const number=escapeXml('DIGITAL CARD');return `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="756" viewBox="0 0 1200 756"><rect width="1200" height="756" rx="40" fill="${bg}"/><g fill="none" stroke="#b5a37b" opacity=".65"><rect x="30" y="30" width="1140" height="696" rx="26"/><ellipse cx="1080" cy="400" rx="280" ry="530" transform="rotate(-28 1080 400)"/><ellipse cx="1080" cy="400" rx="220" ry="470" transform="rotate(-28 1080 400)"/></g><g fill="${ink}"><text x="90" y="150" font-family="Georgia,serif" font-size="70" letter-spacing="13">ELORA</text><text x="94" y="190" font-family="Arial,sans-serif" font-size="22" letter-spacing="16">SKIN</text><text x="1100" y="120" font-family="Arial,sans-serif" font-size="20" text-anchor="end" letter-spacing="5">THE ELORA</text><text x="1100" y="154" font-family="Arial,sans-serif" font-size="20" text-anchor="end" letter-spacing="5">CIRCLE</text><text x="90" y="380" font-family="Georgia,serif" font-style="italic" font-size="37">Your skin. Your season. Your ritual.</text><text x="90" y="565" font-family="Arial,sans-serif" font-size="15" letter-spacing="4">PREPARED FOR</text><text x="90" y="630" font-family="Georgia,serif" font-size="44"${fittedName}>${name}</text><text x="1100" y="630" font-family="Arial,sans-serif" font-size="17" text-anchor="end" letter-spacing="2">${number}</text></g></svg>`;}
document.querySelector('#download-card').addEventListener('click',async()=>{if(!saveLocalCard())return;const button=document.querySelector('#download-card');button.disabled=true;membershipStatus.textContent='Preparing your card…';
 const svg=cardSvg();const svgBlob=new Blob([svg],{type:'image/svg+xml'});const imageUrl=URL.createObjectURL(svgBlob);
 try{const img=new Image();img.src=imageUrl;await img.decode();const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=756;const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0);const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('Unable to create card');const href=URL.createObjectURL(blob);const a=document.createElement('a');a.href=href;a.download='ELORA-Circle-Card.png';a.click();setTimeout(()=>URL.revokeObjectURL(href),1000);membershipStatus.textContent='Your personalized card has been downloaded. No sign-in needed.';}
 catch{membershipStatus.textContent='We couldn’t download the card in this browser. Please try again.';}finally{URL.revokeObjectURL(imageUrl);button.disabled=false;}
});

const privacyDialog=document.querySelector('#privacy-dialog');
document.querySelectorAll('.privacy-trigger').forEach(button=>button.addEventListener('click',()=>showDialog(privacyDialog)));document.querySelector('#close-privacy').addEventListener('click',()=>privacyDialog.close());
const checkoutButton=document.querySelector('#checkout-button');
let checkoutProvider='squarespace';
let approvedStoreUrl=null;
async function loadShop(){
 if(location.protocol==='file:')return;
 try{
  const response=await fetch('/api/shop',{cache:'no-store'});if(!response.ok)return;
  const shop=await response.json();
  checkoutProvider=shop.commerce?.provider||'squarespace';
  if(!shop.checkoutReady)return;
  checkoutAvailable=true;
  if(checkoutProvider==='squarespace'&&shop.commerce?.storeUrl){
   approvedStoreUrl=shop.commerce.storeUrl;
   checkoutLabel='Continue to our store ↗';
   checkoutNote='Your saved selections do not transfer automatically. Re-select these products in our Squarespace store, where confirmed prices, secure checkout, and delivery details are shown.';
   document.querySelector('#fulfillment-status').textContent='Orders fulfilled through our store';
   document.querySelector('#fulfillment-note').textContent='Checkout, order confirmation, and tracking are handled by our connected Squarespace store and Selfnamed. This preview cart is a separate saved selection.';
   document.querySelector('#help-shopping-answer').textContent='Use Continue to our store from your cart. You will re-select your products in the Squarespace store; this preview cart does not transfer. Confirmed prices and checkout terms are shown there.';
  }else{
   checkoutLabel='Secure checkout ↗';
   checkoutNote='You’ll finish your order on Stripe’s secure checkout page.';
   document.querySelectorAll('.shop-card:not([data-availability="planned"]) .product-price small').forEach(el=>el.textContent='USD');
  }
  syncCartCheckout();
 }catch{}
}
checkoutButton.addEventListener('click',async()=>{
 if(!checkoutAvailable||hasPreviewBundle())return;
 checkoutButton.disabled=true;cartStatus.textContent='Opening the store…';
 try{
  const response=await fetch('/api/checkout',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:Object.entries(cart).map(([id,quantity])=>({id,quantity}))})});
  const result=await response.json();if(!response.ok)throw Error(result.error);
  const target=new URL(result.url);
  const valid=target.protocol==='https:'&&(checkoutProvider==='squarespace'?approvedStoreUrl&&target.href===approvedStoreUrl:target.hostname==='checkout.stripe.com');
  if(!valid)throw Error('The store connection needs to be checked. Your selections are saved.');
  location.assign(target.href);
 }catch(error){cartStatus.textContent=error.message||'Checkout is temporarily unavailable.';syncCartCheckout();}
});
loadShop();

const helpDialog=document.querySelector('#help-dialog');
const helpSearch=document.querySelector('#help-search');
function searchHelp(){const query=helpSearch.value.trim();let count=0;document.querySelectorAll('[data-help-question]').forEach(question=>{const match=window.ELORAAnswers?window.ELORAAnswers.matchesHelpQuestion(question.textContent,query):question.textContent.toLowerCase().includes(query.toLowerCase());question.hidden=!match;if(match)count++;});document.querySelector('#help-count').textContent=count+' '+(count===1?'helpful answer':'helpful answers');document.querySelector('#help-no-results').hidden=count>0;}
document.querySelectorAll('[data-open-help]').forEach(button=>button.addEventListener('click',()=>{showDialog(helpDialog);helpSearch.focus()}));
document.querySelector('#close-help').addEventListener('click',()=>helpDialog.close());
helpSearch.addEventListener('input',searchHelp);
document.querySelectorAll('[data-help-link]').forEach(link=>link.addEventListener('click',()=>helpDialog.close()));
document.querySelector('#help-cart').addEventListener('click',()=>{helpDialog.close();showCart()});

// ELORA Concierge: clear AI readiness and local quick answers, never a pretend live agent.
const chatDialog=document.querySelector('#chat-dialog');
const chatMessages=document.querySelector('#chat-messages');
const chatInput=document.querySelector('#chat-input');
const chatStatus=document.querySelector('#chat-status');
const chatSend=document.querySelector('#chat-send');
let aiReady=false,chatBusy=false,chatHistory=[];
const openingMessage='Welcome to ELORA. Let’s find a clear next step. Ask a question or choose a topic below.';
function addChatMessage(role,answer,source){
 const structured=typeof answer==='object'&&answer!==null?answer:{text:String(answer),actions:[]};
 const message=document.createElement('div');message.className='chat-message '+role;
 const label=document.createElement('small');label.textContent=role==='user'?'YOU':source==='ai'?'ELORA · AI ANSWER':'ELORA · PREPARED ANSWER';
 const paragraph=document.createElement('p');paragraph.textContent=structured.text;
 message.append(label,paragraph);
 if(role!=='user'&&Array.isArray(structured.actions)&&structured.actions.length){
  const actions=document.createElement('div');actions.className='chat-actions';
  actions.setAttribute('aria-label','Helpful next steps');
  for(const action of structured.actions.slice(0,4)){
   if(!action||typeof action.label!=='string')continue;
   let control;
   if(action.kind==='email'&&action.value==='supporteloraskin@gmail.com'){
    control=document.createElement('a');control.href='mailto:supporteloraskin@gmail.com';
   }else if(action.kind==='tracking'){
    control=document.createElement('a');control.href='/track-order';
   }else if(action.kind==='policy'&&['returns','shipping'].includes(action.value)){
    control=document.createElement('a');control.href='/policies/'+action.value;
    control.addEventListener('click',event=>{const panel=document.querySelector('#offline-policy-'+action.value);if(panel){event.preventDefault();chatDialog.close();showDialog(panel);}});
   }else if(['section','product','cart','help','topic'].includes(action.kind)){
    control=document.createElement('button');control.type='button';control.addEventListener('click',()=>performChatAction(action));
   }else continue;
   control.textContent=action.label+' ↗';actions.append(control);
  }
  if(actions.children.length)message.append(actions);
 }
 chatMessages.append(message);
 while(chatMessages.children.length>20)chatMessages.firstElementChild.remove();
 // Start a new answer at its beginning, even when its action buttons extend
 // below the conversation viewport.
 chatMessages.scrollTop=role==='assistant'?Math.max(0,message.offsetTop-chatMessages.offsetTop-16):chatMessages.scrollHeight;
}
function preparedAnswer(query){
 const context={products,ingredientConcepts,packagingConcepts,policy:storePolicyDraft,storeConnected:!!approvedStoreUrl,aiReady};
 if(window.ELORAAnswers)return window.ELORAAnswers.respond(query,context);
 return {id:'unavailable',known:false,text:'ELORA prepared answers could not load. Please open FAQs for product, card, and policy information, or email supporteloraskin@gmail.com.',actions:[{label:'Open FAQs',kind:'help'},{label:'Email customer care',kind:'email',value:'supporteloraskin@gmail.com'}]};
}
function performChatAction(action){
 if(action.kind==='topic'){sendChat(action.value);return;}
 if(action.kind==='help'){chatDialog.close();showDialog(helpDialog);helpSearch.focus();return;}
 if(action.kind==='cart'){chatDialog.close();showCart();return;}
 if(action.kind==='product'){
  const id=action.value;
  if(!['cleanser','serum','cream','eye','scrub','sunscreen','pads','toner'].includes(id))return;
  const productButton=document.querySelector('.shop-card[data-shop-id="'+id+'"] [data-product]');
  if(productButton){chatDialog.close();productButton.click();}
  return;
 }
 if(action.kind==='section'){
  if(!/^#(?:collection|ingredients(?:-(?:cleanser|serum|cream|eye|scrub|sunscreen|pads|toner))?|skin-quiz|membership|contact|customer-reviews|philosophy|ritual|learn)$/.test(action.value))return;
  const target=document.querySelector(action.value);if(!target)return;
  chatDialog.close();
  const parentDetails=target.closest('details');if(parentDetails)parentDetails.open=true;
  target.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
  const heading=target.querySelector('h2,h3')||target;
  if(!heading.hasAttribute('tabindex'))heading.setAttribute('tabindex','-1');
  heading.focus({preventScroll:true});
 }
}
async function checkChatConnection(){
 if(location.protocol==='file:')return;
 try{
  const response=await fetch('/api/chat',{cache:'no-store'});if(!response.ok)return;
  const state=await response.json();aiReady=state.aiReady===true;
  document.querySelector('#chat-mode').textContent=aiReady?'Instant answers + AI assistant':'Instant answers · AI not connected';
  if(aiReady){document.querySelector('#chat-disclosure').textContent='Common questions get instant prepared answers. Other questions can use the connected AI service, clearly labeled. This is automated assistance, not a human agent or medical advice.';document.querySelector('#chat-privacy').textContent='Questions answered by AI share your message and recent conversation with OpenAI. Instant prepared answers stay on this page. ELORA does not save chat transcripts. Leave out payment, address, and medical details.';}
 }catch{}
}
async function sendChat(text){
 text=text.trim().slice(0,600);if(!text||chatBusy)return;
 chatBusy=true;chatSend.disabled=true;chatInput.value='';addChatMessage('user',text);
 const prepared=preparedAnswer(text);
 try{
  if(prepared.known||!aiReady){
   addChatMessage('assistant',prepared,'quick');
   chatStatus.textContent=prepared.known?'Instant prepared answer · no AI request sent':'Prepared information · try a topic or contact customer care';
  }else{
   // Keep locally answered questions out of future AI requests too.
   chatHistory.push({role:'user',content:text});chatHistory=chatHistory.slice(-9);
   chatStatus.textContent='ELORA AI is thinking…';
   const response=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:chatHistory}),signal:AbortSignal.timeout(30000)});
   const result=await response.json();if(!response.ok)throw Error(result.error||'AI is unavailable.');
   if(typeof result.answer!=='string'||!result.answer.trim())throw Error('AI could not produce an answer.');
   addChatMessage('assistant',result.answer,'ai');chatHistory.push({role:'assistant',content:result.answer.slice(0,800)});chatStatus.textContent='AI answer · please verify product details';
  }
 }catch(error){
  chatStatus.textContent=(error.name==='TimeoutError'?'AI took too long.':'AI is temporarily unavailable.')+' Prepared guidance is available below.';
  addChatMessage('assistant',prepared,'quick');chatHistory.push({role:'assistant',content:prepared.text.slice(0,800)});
 }
 finally{chatBusy=false;chatSend.disabled=false;chatInput.focus();}
}
document.querySelectorAll('#open-chat,[data-open-chat]').forEach(button=>button.addEventListener('click',()=>{showDialog(chatDialog);chatInput.focus()}));
document.querySelector('#close-chat').addEventListener('click',()=>chatDialog.close());
document.querySelector('#chat-form').addEventListener('submit',e=>{e.preventDefault();sendChat(chatInput.value)});
chatInput.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();sendChat(chatInput.value)}});
document.querySelectorAll('[data-chat-topic]').forEach(button=>button.addEventListener('click',()=>sendChat(button.dataset.chatTopic)));
document.querySelector('#chat-clear').addEventListener('click',()=>{if(chatBusy)return;chatHistory=[];chatMessages.replaceChildren();addChatMessage('assistant',openingMessage,'quick');chatStatus.textContent='Conversation cleared from this page.';chatInput.focus()});
document.querySelector('#chat-help').addEventListener('click',()=>{chatDialog.close();showDialog(helpDialog);helpSearch.focus()});
checkChatConnection();

// The standalone review opens the same policy content in accessible dialogs.
document.querySelectorAll('[data-policy-open]').forEach(link=>link.addEventListener('click',e=>{const panel=document.querySelector('#offline-policy-'+link.dataset.policyOpen);if(panel){e.preventDefault();showDialog(panel)}}));
document.querySelectorAll('[data-close-policy]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));


// The preference quiz stays in page memory. No quiz answers enter storage or chat.
const quizForm=document.querySelector('#skin-quiz-form');
const quizOptions=document.querySelector('#quiz-options');
const quizLegend=document.querySelector('#quiz-question');
const quizNext=document.querySelector('#quiz-next');
const quizBack=document.querySelector('#quiz-back');
const quizResultPanel=document.querySelector('#quiz-result');
const quizStatus=document.querySelector('#quiz-status');
let quizStep=0,quizAnswers={};
function renderQuizQuestion(moveFocus=false){
 const question=quizQuestions[quizStep];
 quizForm.hidden=false;quizResultPanel.hidden=true;
 document.querySelector('#quiz-step-label').textContent='QUESTION '+String(quizStep+1).padStart(2,'0')+' OF 05';
 document.querySelector('#quiz-progress').value=quizStep;
 quizLegend.textContent=question.title;
 document.querySelector('#quiz-hint').textContent=question.hint;
 quizOptions.replaceChildren();
 for(const option of question.options){
  const label=document.createElement('label');label.className='quiz-option';
  const input=document.createElement('input');input.type='radio';input.name='quiz-answer';input.value=option.value;input.required=true;input.checked=quizAnswers[question.id]===option.value;input.setAttribute('aria-describedby','quiz-hint');
  const copy=document.createElement('span');const title=document.createElement('strong');title.textContent=option.label;const detail=document.createElement('small');detail.textContent=option.detail;copy.append(title,detail);label.append(input,copy);quizOptions.append(label);
 }
 quizBack.disabled=quizStep===0;
 quizNext.disabled=!question.options.some(option=>option.value===quizAnswers[question.id]);
 quizNext.textContent=quizStep===quizQuestions.length-1?'See my ritual →':'Continue →';
 quizStatus.textContent='';
 if(moveFocus)quizLegend.focus();
}
quizOptions.addEventListener('change',e=>{
 if(e.target.name!=='quiz-answer')return;
 const question=quizQuestions[quizStep];
 if(question.options.some(option=>option.value===e.target.value)){quizAnswers[question.id]=e.target.value;quizNext.disabled=false;}
});
function showQuizResult(){
 const result=buildQuizResult(quizAnswers);if(!result){quizStatus.textContent='Please answer each question before viewing your ritual.';return;}
 quizForm.hidden=true;quizResultPanel.hidden=false;
 document.querySelector('#quiz-step-label').textContent='YOUR FIVE ANSWERS · YOUR DIRECTION';
 document.querySelector('#quiz-progress').value=5;
 document.querySelector('#quiz-result-title').textContent=result.title;
 document.querySelector('#quiz-result-summary').textContent=result.summary;
 const chips=document.querySelector('#quiz-result-chips');chips.replaceChildren();
 for(const text of result.chips){const chip=document.createElement('span');chip.textContent=text;chips.append(chip);}
 const list=document.querySelector('#quiz-result-products');list.replaceChildren();
 result.productIds.forEach((id,index)=>{
  const li=document.createElement('li');const number=document.createElement('span');number.textContent=String(index+1).padStart(2,'0');
  const name=document.createElement('h4');name.textContent=products[id].name;
  const reason=document.createElement('p');reason.textContent=result.reasons[id];
  const button=document.createElement('button');button.type='button';button.dataset.quizProduct=id;button.textContent='View this concept ↗';button.setAttribute('aria-label','View '+products[id].name+' concept');
  li.append(number,name,reason,button);list.append(li);
 });
 const notes=document.querySelector('#quiz-result-notes');notes.replaceChildren();
 for(const text of result.notes){const li=document.createElement('li');li.textContent=text;notes.append(li);}
 const sun=document.querySelector('#quiz-sun-note');sun.hidden=!result.sunCare;sun.textContent=result.sunCare||'';
 quizStatus.textContent='Your concept shortlist is ready. Nothing has been added to your cart.';
 document.querySelector('#quiz-result-title').focus();
}
quizForm.addEventListener('submit',e=>{
 e.preventDefault();const question=quizQuestions[quizStep];
 if(!question.options.some(option=>option.value===quizAnswers[question.id]))return;
 if(quizStep<quizQuestions.length-1){quizStep++;renderQuizQuestion(true);}else showQuizResult();
});
quizBack.addEventListener('click',()=>{if(quizStep>0){quizStep--;renderQuizQuestion(true);}});
document.querySelector('#quiz-edit').addEventListener('click',()=>{quizStep=0;renderQuizQuestion(true);});
document.querySelector('#quiz-restart').addEventListener('click',()=>{quizStep=0;quizAnswers={};renderQuizQuestion(true);quizStatus.textContent='Your quiz answers have been cleared from this page.';});
document.querySelector('#quiz-result-products').addEventListener('click',e=>{const button=e.target.closest('[data-quiz-product]');if(!button)return;const id=button.dataset.quizProduct;if(availableIds.includes(id))document.querySelector('[data-shop-id="'+id+'"] [data-product]')?.click();});
renderQuizQuestion();

})();
