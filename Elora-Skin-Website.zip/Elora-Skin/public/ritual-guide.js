(()=>{
  'use strict';
  const root=document.querySelector('.ritual-guide');
  if(!root||root.dataset.ritualGuideReady==='true')return;
  root.dataset.ritualGuideReady='true';
  const tabs=[...root.querySelectorAll('[data-guide-moment]')];
  const panel=root.querySelector('#moment-panel');
  const save=root.querySelector('#save-ritual');
  const saveStatus=root.querySelector('#save-status');
  const validMoments=['morning','evening'];
  let selected='morning',saved=null;
  try{const value=localStorage.getItem('elora-moment');if(validMoments.includes(value)){saved=value;selected=value}}catch{}
  const intentions={
    comfort:{label:'Comfort',note:'Keep comfort at the center. Explore ingredient directions, without rushing to add more.'},
    radiance:{label:'Radiant-looking finish',note:'A radiant-looking finish is a cosmetic goal. The serum is an optional concept to explore; its performance still needs verification.'},
    consistency:{label:'A simple habit',note:'Make a repeatable pause the intention. You do not need every product or an extra step to make that moment your own.'}
  };
  function choice(name,fallback){return root.querySelector('input[name="'+name+'"]:checked')?.value||fallback}
  function updateSave(){
    const active=saved===selected;
    save.setAttribute('aria-pressed',String(active));
    save.replaceChildren(document.createTextNode(active?'Moment saved ':'Save this moment '));
    const symbol=document.createElement('span');symbol.setAttribute('aria-hidden','true');symbol.textContent=active?'✓':'＋';save.append(symbol);
    saveStatus.textContent=active?(selected==='morning'?'Morning':'Evening')+' moment saved on this device.':'';
  }
  function render(announce=false){
    const morning=selected==='morning';
    const pace=choice('guide-pace','essential');
    const intention=intentions[choice('guide-intention','comfort')]||intentions.comfort;
    root.dataset.guideMoment=selected;root.dataset.guidePace=pace;
    tabs.forEach(tab=>{const active=tab.dataset.guideMoment===selected;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1});
    panel.setAttribute('aria-labelledby',selected+'-tab');
    root.querySelector('#moment-kicker').textContent=morning?'A FRESH START':'A SOFTER FINISH';
    root.querySelector('#moment-title').textContent=morning?'Begin with yourself.':'Let the day fall away.';
    root.querySelector('#moment-copy').textContent=morning?'A morning planning outline: explore cleansing and moisturizing concepts, with a separate reminder about tested sun protection.':pace==='essential'?'Keep your evening outline close to cleansing and moisturizing. The serum remains an optional idea to browse.':'An evening planning outline with space to explore the optional serum concept between cleansing and moisturizing ideas.';
    root.querySelector('.guide-plan-mark').textContent=morning?'AM':'PM';
    root.querySelector('#guide-moment-chip').textContent=morning?'Morning':'Evening';
    root.querySelector('#guide-pace-chip').textContent=pace==='essential'?'Simple pace':'Room to explore';
    root.querySelector('#guide-intention-chip').textContent=intention.label;
    root.querySelector('#guide-intention-note').textContent=intention.note;
    root.querySelectorAll('[data-guide-plan]').forEach(plan=>{plan.hidden=plan.dataset.guidePlan!==selected});
    root.querySelector('#guide-optional-message').hidden=morning||pace!=='essential';
    root.querySelector('.guide-optional-step').hidden=pace==='essential';
    root.querySelector('[data-guide-plan="evening"] li:last-child .guide-step-number').textContent=pace==='essential'?'02':'03';
    updateSave();
    if(announce)root.querySelector('#guide-plan-status').textContent=(morning?'Morning':'Evening')+' planning outline updated. '+(pace==='essential'?'Simple pace.':'Room to explore.');
  }
  tabs.forEach((tab,index)=>{
    tab.addEventListener('click',()=>{selected=tab.dataset.guideMoment;render(true)});
    tab.addEventListener('keydown',event=>{
      let next=null;
      if(event.key==='ArrowRight')next=tabs[(index+1)%tabs.length];
      if(event.key==='ArrowLeft')next=tabs[(index-1+tabs.length)%tabs.length];
      if(event.key==='Home')next=tabs[0];
      if(event.key==='End')next=tabs[tabs.length-1];
      if(next){event.preventDefault();selected=next.dataset.guideMoment;render(true);next.focus()}
    });
  });
  root.querySelectorAll('input[name="guide-intention"],input[name="guide-pace"]').forEach(input=>input.addEventListener('change',()=>render(true)));
  save.addEventListener('click',()=>{
    const next=saved===selected?null:selected;
    try{
      if(next)localStorage.setItem('elora-moment',next);else localStorage.removeItem('elora-moment');
      saved=next;updateSave();
      if(!next)saveStatus.textContent='Your saved moment has been removed from this device.';
    }catch{saveStatus.textContent='This browser could not save the choice. You can still explore both plans.'}
  });
  render();
})();
