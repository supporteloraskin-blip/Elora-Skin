declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    STRIPE_SECRET_KEY?: string;
    STRIPE_WEBHOOK_SECRET?: string;
    SHOP_READY?: string;
    PRICES_APPROVED?: string;
    SHIPPING_AMOUNT_CENTS?: string;
    SHIPPING_COUNTRIES?: string;
    COMMERCE_PROVIDER?: string;
    SQUARESPACE_STORE_URL?: string;
    SQUARESPACE_READY?: string;
    SELFNAMED_READY?: string;
    CHAT_ENABLED?: string;
    OPENAI_API_KEY?: string;
    OPENAI_CHAT_MODEL?: string;
    CHAT_RATE_SALT?: string;
    BUCKET?: R2Bucket;
  }
}
