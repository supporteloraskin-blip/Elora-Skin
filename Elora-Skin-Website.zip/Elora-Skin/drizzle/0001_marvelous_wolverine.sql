CREATE TABLE `chat_rate_limits` (
	`bucket_key` text PRIMARY KEY NOT NULL,
	`used` integer DEFAULT 0 NOT NULL,
	`expires_at` integer NOT NULL
);
