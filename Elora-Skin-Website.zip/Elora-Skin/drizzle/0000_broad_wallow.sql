CREATE TABLE `members` (
	`user_id` text PRIMARY KEY NOT NULL,
	`member_id` text NOT NULL,
	`display_name` text NOT NULL,
	`card_style` text DEFAULT 'olive' NOT NULL,
	`favorites` text DEFAULT '[]' NOT NULL,
	`moment` text DEFAULT 'morning' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `members_member_id_unique` ON `members` (`member_id`);--> statement-breakpoint
CREATE TABLE `orders` (
	`session_id` text PRIMARY KEY NOT NULL,
	`user_id` text,
	`payment_status` text DEFAULT 'pending' NOT NULL,
	`amount_total` integer DEFAULT 0 NOT NULL,
	`currency` text DEFAULT 'usd' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
