# ELORA SKIN — Cloudflare import preparation

This is a separate hosting copy of the existing ELORA website. It preserves the
homepage, images, local cart, ELORA Circle cards, skin quiz, policies and the
proposed $169 all-eight bundle. The original hosted site is unchanged.

## Current status

This repository is prepared for build verification and import into a private
GitHub repository. It has not been uploaded to GitHub or deployed to your own
Cloudflare account. It contains source code and public brand assets, not the
original site's database contents, secrets or account sessions.

Checkout, supplier fulfillment, approved product specifications and final prices
still need confirmation. The current commerce adapter is the earlier Squarespace
proposal; using your Shopify store requires its own verified integration. Do not
set readiness flags merely to open checkout.

## Prepare the Cloudflare account before deploying

1. Create a Cloudflare D1 database named `elora-skin`. Replace the explicit
   placeholder database ID in `wrangler.jsonc` with its real database ID.
2. Apply the SQL migrations in `drizzle` to that database. With Wrangler signed
   into the intended account, run `pnpm db:migrate`.
3. Decide the site's audience. Both `workers_dev` and `preview_urls` are disabled,
   and no custom routes are declared. Preserve private access until the owner
   explicitly approves public launch. Configure the intended route and appropriate
   access controls before making the website accessible.
4. Add any needed runtime secrets directly in Cloudflare. No secret values are
   included here. AI is optional and disabled by default.

## Import from GitHub

Create a private repository and push this code to it. In Cloudflare, open
Workers & Pages, choose Create application, then Connect GitHub. Authorize only
that repository and select it for import.

- Build command: `pnpm run build`
- Deploy command: `pnpm run deploy`
- Project root: repository root
- Node.js: 22.13 or newer; package manager version is declared in `package.json`

Do not deploy with the placeholder D1 ID. Do not change DNS or the Shopify store
merely to prepare this import. Verify the imported site before switching traffic.

## Local validation

Run `pnpm install`, `pnpm test`, then `pnpm run build`. Generated output goes to
`dist`, which is not part of the repository. Deploy the generated Worker using
its generated `dist/server/wrangler.json` configuration.

## Identity and commerce

The original host's ChatGPT identity headers are unavailable on an independent
Worker. This copy does not trust those headers. Legacy server account endpoints
remain unauthenticated; the existing browser-local membership card still works.

Selfnamed does not become connected by importing website code. The real supplier
products, store checkout, billing, shipping and order flow must be configured and
tested separately. The eight-product bundle also needs a real fulfillment test.
