import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import { randomUUID } from 'node:crypto';
import ts from 'typescript';
import { readBoundedText, RequestBodyError } from '../lib/request-body.ts';

// Execute the real handlers with account and database boundaries stubbed. The
// requests still pass through authentication, parsing and response handling.
function memberHandlers({ signedIn = true } = {}) {
  const writes = [];
  let databaseCalls = 0;
  const member = { memberId: 'ELR-TEST', favorites: '[]' };
  const chain = {
    values(value) { writes.push(value); return this; },
    set(value) { writes.push(value); return this; },
    from() { return this; }, where() { return this; }, returning() { return this; },
    async onConflictDoNothing() {}, async get() { return member; },
  };
  const imports = {
    'drizzle-orm': { eq: (...values) => values },
    '../../../db': { getDb() { databaseCalls++; return { insert: () => chain, select: () => chain, update: () => chain }; } },
    '../../../db/schema': { members: { userId: 'userId' } },
    '../../chatgpt-auth': { async getChatGPTUser() { return signedIn ? { userId: 'test-user' } : null; } },
    '../../../lib/request-body': { readBoundedText, RequestBodyError },
  };
  const source = readFileSync(new URL('../app/api/member/route.ts', import.meta.url), 'utf8');
  const { outputText } = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } });
  const context = { exports: {}, Response, URL, crypto: { randomUUID }, require(name) { assert.ok(Object.hasOwn(imports, name), name); return imports[name]; } };
  runInNewContext(outputText, context);
  return { handlers: context.exports, writes, databaseCalls: () => databaseCalls };
}

function request(method, value) {
  return new Request('https://elora.test/api/member', { method, headers: { Origin: 'https://elora.test', 'Content-Type': 'application/json' }, body: JSON.stringify(value) });
}

test('authenticated membership writes reject null, arrays and scalar JSON before database access', async () => {
  for (const method of ['POST', 'PATCH']) {
    const { handlers, databaseCalls } = memberHandlers();
    for (const value of [null, [], [{ name: 'Visitor' }], 'Visitor', 0, 7, true, false]) {
      const response = await handlers[method](request(method, value));
      assert.equal(response.status, 400, `${method}: ${JSON.stringify(value)}`);
      assert.equal(typeof (await response.json()).error, 'string');
    }
    assert.equal(databaseCalls(), 0);
  }
});

test('membership shape validation preserves authentication and accepts ordinary object updates', async () => {
  for (const method of ['POST', 'PATCH']) {
    const anonymous = memberHandlers({ signedIn: false });
    assert.equal((await anonymous.handlers[method](request(method, null))).status, 401);
    assert.equal(anonymous.databaseCalls(), 0);
    const signedIn = memberHandlers();
    const response = await signedIn.handlers[method](request(method, { name: '  ELORA Visitor  ', style: 'ivory' }));
    assert.equal(response.status, 200);
    assert.equal(signedIn.writes[0].displayName, 'ELORA Visitor');
    assert.equal(signedIn.writes[0].cardStyle, 'ivory');
  }
});

test('membership favorites accept catalog strings only, never coerced arrays or values', async () => {
  const { handlers, writes } = memberHandlers();
  const response = await handlers.PATCH(request('PATCH', { favorites: [['cleanser'], ['serum'], {}, 1, null, 'eye', 'eye', 'sunscreen'] }));
  assert.equal(response.status, 200);
  assert.equal(writes[0].favorites, '["eye"]');
});

test('membership POST and PATCH bound actual UTF-8 bytes before any database work', async () => {
  for (const method of ['POST', 'PATCH']) {
    const { handlers, databaseCalls } = memberHandlers();
    const response = await handlers[method](request(method, { name: 'é'.repeat(2100) }));
    assert.equal(response.status, 413);
    assert.equal((await response.json()).code, 'payload_too_large');
    assert.equal(databaseCalls(), 0);
  }
});
