import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac, webcrypto } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import ts from 'typescript';
import { readBoundedBody, readBoundedText, decodeRequestBody, RequestBodyError } from '../lib/request-body.ts';

const encoder = new TextEncoder();
function chunkedRequest(chunks, headers = {}, onCancel = () => {}) {
  let index = 0;
  return new Request('https://elora.example/api/test', {
    method: 'POST', headers, duplex: 'half',
    body: new ReadableStream({
      pull(controller) {
        if (index === chunks.length) controller.close();
        else controller.enqueue(chunks[index++]);
      },
      cancel: onCancel,
    }, { highWaterMark: 0 }),
  });
}

test('reads actual bytes at the exact limit without Content-Length', async () => {
  const request = chunkedRequest([encoder.encode('ab'), encoder.encode('cd')]);
  assert.equal(await readBoundedText(request, 4), 'abcd');
  assert.equal(request.body.locked, false);
});

test('counts UTF-8 bytes, including a character split across chunks', async () => {
  const bytes = encoder.encode('{"name":"É🌿"}');
  const request = chunkedRequest([bytes.slice(0, 10), bytes.slice(10, 12), bytes.slice(12)]);
  assert.equal(await readBoundedText(request, bytes.length), '{"name":"É🌿"}');
  await assert.rejects(readBoundedText(chunkedRequest([bytes]), bytes.length - 1), error => error instanceof RequestBodyError && error.code === 'payload_too_large');
});

test('cannot bypass the limit with a false short Content-Length', async () => {
  const request = chunkedRequest([encoder.encode('123'), encoder.encode('456')], { 'Content-Length': '1' });
  await assert.rejects(readBoundedText(request, 5), error => error.code === 'payload_too_large');
});

test('oversized input is cancelled before reading remaining chunks', async () => {
  let pulled = 0; let cancelled = 0;
  const request = new Request('https://elora.example/api/test', {
    method: 'POST', duplex: 'half',
    body: new ReadableStream({
      pull(controller) { pulled++; controller.enqueue(encoder.encode('abcd')); },
      cancel() { cancelled++; },
    }, { highWaterMark: 0 }),
  });
  await assert.rejects(readBoundedBody(request, 5), error => error.code === 'payload_too_large');
  assert.equal(pulled, 2);
  assert.equal(cancelled, 1);
  assert.equal(request.body.locked, false);
});

test('cancellation failures do not replace the payload-too-large result', async () => {
  const request = chunkedRequest([encoder.encode('oversized')], {}, () => { throw Error('cancel failed'); });
  await assert.rejects(readBoundedBody(request, 1), error => error.code === 'payload_too_large');
});

test('malformed UTF-8 is rejected instead of inserting replacement characters', async () => {
  for (const bytes of [new Uint8Array([0xc3]), new Uint8Array([0xff]), new Uint8Array([0xc0, 0x80])]) {
    await assert.rejects(readBoundedText(chunkedRequest([bytes]), 10), error => error.code === 'invalid_body');
  }
});

test('broken streams become a controlled invalid-body error', async () => {
  const request = new Request('https://elora.example/api/test', {
    method: 'POST', duplex: 'half',
    body: new ReadableStream({ start(controller) { controller.error(Error('transport failed')); } }),
  });
  await assert.rejects(readBoundedBody(request, 10), error => error.code === 'invalid_body');
  assert.equal(request.body.locked, false);
});

test('raw body retains BOM, non-ASCII text and CRLF for signature verification', async () => {
  const raw = encoder.encode('\ufeff{"message":"É🌿"}\r\n');
  const received = await readBoundedBody(chunkedRequest([raw.slice(0, 1), raw.slice(1, 8), raw.slice(8)]), 100);
  assert.deepEqual(received, raw);
  const prefix = encoder.encode('1234567890.');
  const signed = new Uint8Array(prefix.length + received.length);
  signed.set(prefix); signed.set(received, prefix.length);
  const expected = createHmac('sha256', 'test-secret').update(prefix).update(raw).digest('hex');
  assert.equal(createHmac('sha256', 'test-secret').update(signed).digest('hex'), expected);
  // Text decoding is only for JSON parsing, after the raw-byte signature check.
  assert.deepEqual(JSON.parse(decodeRequestBody(received)), { message: 'É🌿' });
});

test('empty body stays empty for the caller to reject as invalid JSON', async () => {
  const body = await readBoundedText(new Request('https://elora.example/api/test', { method: 'POST' }), 10);
  assert.equal(body, '');
  assert.throws(() => JSON.parse(body), SyntaxError);
});

function routeHandlers(relativeFile, imports) {
  const source = readFileSync(new URL(relativeFile, import.meta.url), 'utf8');
  const { outputText } = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } });
  const context = { exports: {}, Response, URL, TextEncoder, Uint8Array, crypto: webcrypto, require(name) { assert.ok(Object.hasOwn(imports, name), name); return imports[name]; } };
  runInNewContext(outputText, context);
  return context.exports;
}

function webhookHandlers() {
  const writes = [];
  const secret = 'test-only-signing-secret';
  const handlers = routeHandlers('../app/api/stripe/webhook/route.ts', {
    'cloudflare:workers': { env: { STRIPE_WEBHOOK_SECRET: secret } },
    '../../../../db': { getDb: () => ({ insert: () => ({ values(value) { writes.push(value); return { async onConflictDoUpdate() {} }; } }) }) },
    '../../../../db/schema': { orders: { sessionId: 'session_id' } },
    '../../../../lib/shop': { shopJson: (value, status = 200) => Response.json(value, { status }) },
    '../../../../lib/request-body': { readBoundedBody, decodeRequestBody, RequestBodyError },
  });
  function request(bytes, header) {
    const timestamp = String(Math.floor(Date.now() / 1000));
    const digest = createHmac('sha256', secret).update(timestamp + '.').update(bytes).digest('hex');
    return new Request('https://elora.example/api/stripe/webhook', { method: 'POST', headers: { 'stripe-signature': header ?? `t=${timestamp},v1=${digest}` }, body: bytes });
  }
  return { handlers, writes, request };
}

test('actual Stripe handler rejects malformed v1 header values without throwing', async () => {
  const { handlers, writes, request } = webhookHandlers();
  const timestamp = String(Math.floor(Date.now() / 1000));
  for (const signature of [`t=${timestamp},v1`, `t=${timestamp},v1=`, `t=${timestamp},v1=not-hex`, `t=${timestamp},v1=${'a'.repeat(63)}`]) {
    const response = await handlers.POST(request(encoder.encode('{}'), signature));
    assert.equal(response.status, 400);
    assert.equal((await response.json()).error, 'Invalid signature.');
  }
  assert.equal(writes.length, 0);
});

test('actual Stripe handler verifies unchanged BOM/Unicode/newline bytes before recording paid events', async () => {
  const { handlers, writes, request } = webhookHandlers();
  const event = { type: 'checkout.session.completed', data: { object: { id: 'cs_test_exact_bytes', payment_status: 'paid', amount_total: 1600, currency: 'usd', metadata: { note: 'É🌿' } } } };
  const bytes = encoder.encode('\ufeff' + JSON.stringify(event) + '\r\n');
  const response = await handlers.POST(request(bytes));
  assert.equal(response.status, 200);
  assert.equal(writes.length, 1);
  assert.equal(writes[0].sessionId, event.data.object.id);
  assert.equal(writes[0].paymentStatus, 'paid');
});

test('actual Stripe handler bounds bytes and rejects signed malformed content without database writes', async () => {
  const { handlers, writes, request } = webhookHandlers();
  const oversized = new Uint8Array(1048577);
  let response = await handlers.POST(request(oversized, 'invalid-signature'));
  assert.equal(response.status, 413);
  assert.equal((await response.json()).code, 'payload_too_large');
  for (const bytes of [encoder.encode('null'), encoder.encode('[]'), new Uint8Array([0xff])]) {
    response = await handlers.POST(request(bytes));
    assert.equal(response.status, 400);
  }
  assert.equal(writes.length, 0);
});

test('actual checkout handler bounds bytes and rejects invalid UTF-8 before checking readiness', async () => {
  const handlers = routeHandlers('../app/api/checkout/route.ts', {
    'cloudflare:workers': { env: {} },
    '../../../lib/shop': { catalog: { cleanser: {} }, checkoutReady: () => false, shopJson: (value, status = 200) => Response.json(value, { status }), shopOrigin: request => new URL(request.url).origin },
    '../../chatgpt-auth': { getChatGPTUser: async () => null },
    '../../../db': { getDb() { throw Error('Database must not be called'); } },
    '../../../db/schema': { orders: {} },
    '../../../lib/commerce': { commerceStatus: () => ({ provider: 'squarespace' }) },
    '../../../lib/request-body': { readBoundedText, RequestBodyError },
  });
  const request = bytes => new Request('https://elora.example/api/checkout', { method: 'POST', headers: { Origin: 'https://elora.example', 'Content-Type': 'application/json' }, body: bytes });
  let response = await handlers.POST(request(encoder.encode(JSON.stringify({ name: 'é'.repeat(2100) }))));
  assert.equal(response.status, 413);
  assert.equal((await response.json()).code, 'payload_too_large');
  response = await handlers.POST(request(new Uint8Array([0xff])));
  assert.equal(response.status, 400);
  response = await handlers.POST(request(encoder.encode('{"items":[{"id":"cleanser","quantity":1}]}')));
  assert.equal(response.status, 503);
});
