import test from 'node:test';
import assert from 'node:assert/strict';
import { getCustomerReviewFeed, selectPublishableReviews } from '../lib/reviews.ts';
const order = { orderKey: 'private_order_key_123456', productIds: ['cleanser'], paymentStatus: 'paid', fulfillmentStatus: 'fulfilled', email: 'private@example.com' };
const review = { id: 'review_123456', orderKey: order.orderKey, productId: 'cleanser', displayName: 'Customer', rating: 4, title: 'A review', text: 'A customer experience.', createdAt: '2026-01-01T12:00:00Z', publicationConsent: true, moderationStatus: 'approved', email: 'private@example.com' };
test('unconnected reviews feed is empty without invented counts or ratings', async () => {
 assert.deepEqual(await getCustomerReviewFeed(), { connected: false, reviews: [], count: 0, averageRating: null });
});
test('verified label requires matching product, paid and fulfilled order evidence', () => {
 assert.equal(selectPublishableReviews([review], []).length, 0);
 for (const patch of [{ paymentStatus: 'pending' }, { paymentStatus: 'refunded' }, { fulfillmentStatus: 'unfulfilled' }, { productIds: ['eye'] }, { orderKey: 'wrong' }]) assert.equal(selectPublishableReviews([review], [{ ...order, ...patch }]).length, 0);
 assert.equal(selectPublishableReviews([{ ...review, verifiedPurchase: true }], []).length, 0);
 const publicReview = selectPublishableReviews([review], [order])[0];
 assert.equal(publicReview.verifiedPurchase, true);
 assert.equal('orderKey' in publicReview, false);
 assert.equal('email' in publicReview, false);
 assert.equal('publicationConsent' in publicReview, false);
});
test('only valid, consented, approved reviews of released catalog entries are publishable', () => {
 for (const patch of [{ publicationConsent: false }, { moderationStatus: 'pending' }, { rating: 0 }, { rating: 6 }, { productId: 'sunscreen' }, { text: '' }, { title: 'x'.repeat(101) }, { createdAt: 'not-a-date' }]) assert.equal(selectPublishableReviews([{ ...review, ...patch }], [order]).length, 0);
 assert.equal(selectPublishableReviews([review, review], [order]).length, 1);
});
