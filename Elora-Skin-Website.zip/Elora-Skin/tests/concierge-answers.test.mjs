import test from 'node:test';
import assert from 'node:assert/strict';
import '../public/concierge-answers.js';
const {respond,matchesHelpQuestion}=globalThis.ELORAAnswers;
const context={products:{cleanser:{name:'The Gentle Silk Cleanser',description:'A gentle-cleansing development concept.',price:16,size:'120 mL'},serum:{name:'Radiance Renewal Serum',price:22,size:'30 mL'}},ingredientConcepts:{products:{cleanser:{ingredients:['aloe','jojoba']},serum:{ingredients:['rosehip']}},botanicals:{aloe:{name:'Aloe vera'},jojoba:{name:'Jojoba seed oil'},rosehip:{name:'Rosehip seed oil'}}}};
test('product questions answer the selected product and offer a real detail action',()=>{
 const ingredients=respond('What ingredients are in the cleanser?',context);
 assert.equal(ingredients.id,'product-cleanser');assert.match(ingredients.text,/Aloe vera, Jojoba seed oil/);assert.match(ingredients.text,/not a complete ingredient label/);assert.ok(ingredients.actions.some(x=>x.kind==='product'&&x.value==='cleanser'));
 const price=respond('How much is the cleanser?',context);assert.match(price.text,/\$16\.00/);assert.match(price.text,/proposed/);
 const eye=respond('What kind of bottle is the eye cream in?',context);assert.equal(eye.id,'product-eye');assert.match(eye.text,/airless pump/);
 const serum=respond('Is the serum a dropper?',context);assert.equal(serum.id,'product-serum');assert.match(serum.text,/dropper/);
});
test('bounded words do not mistake paid for AI or incidental strings for greetings',()=>{
 assert.equal(respond('Are you paid?',context).id,'unknown');
 assert.equal(respond('What happened yesterday?',context).id,'unknown');
 assert.equal(respond('This is a complicated question about vitamins.',context).id,'unknown');
 assert.equal(respond('Are you an AI chatbot?',context).id,'assistant-mode');
});
test('explicitly excluded topics do not hijack the actual question',()=>{
 assert.equal(respond("I’m not asking about sunscreen; how do I make a member card?",context).id,'membership');
 assert.equal(respond("I don't need shipping details. Tell me about cleanser ingredients.",context).id,'product-cleanser');
 assert.equal(respond("I don't want a card, but how does shipping work?",context).id,'shipping');
 assert.equal(respond('Is the serum not organic?',context).id,'product-serum');
});
test('no certification, product-use or sunscreen performance is invented',()=>{
 assert.match(respond('Is ELORA certified organic?',context).text,/has not been verified/);
 assert.match(respond('Is the cleanser fragrance-free?',context).text,/not verified/);
 assert.match(respond('How often should I use the toner?',context).text,/directions.*not available/);
 const sunscreen=respond('What SPF is your sunscreen?',context);assert.equal(sunscreen.id,'product-sunscreen');assert.match(sunscreen.text,/not an available sun-protection product/);
 assert.equal(respond('Which product is organic?',context).id,'claims');
});
test('order and privacy questions never pretend access or require sensitive details',()=>{
 assert.equal(respond('Where is my order number 87654?',context).id,'order-support');
 assert.match(respond('Track my parcel please',context).text,/cannot look up/);
 assert.equal(respond('My card number is 4242 4242 4242 4242',context).id,'privacy-sensitive');
 assert.equal(respond('What are your shipping and return policies?',context).id,'policies');
 assert.match(respond('Can I order now?',context).text,/not active yet/);
});
test('simple ritual provides direct guidance; explicit quiz requests explain the quiz',()=>{
 const ritual=respond('How do I build a simple ritual?',context);assert.equal(ritual.id,'ritual');assert.match(ritual.text,/morning or evening/);assert.match(ritual.text,/do not need every step/);assert.ok(ritual.actions.some(x=>x.value==='#learn'));
 assert.equal(respond('Help me build a routine',context).id,'ritual');
 assert.equal(respond('How does the skin quiz work?',context).id,'quiz');
 assert.match(respond('Who is the founder?',context).text,/ELORA SKIN’s vision/);
 for(const query of ['Who is the founder?','Tell me the creator','What is the brand story?'])assert.doesNotMatch(respond(query,context).text,/Lytrese|Hamilton|founded by|created by|brand vision:/i);
});
test('unknown questions remain explicit and prepared answers contain only safe action types',()=>{
 const unknown=respond('Can you book a helicopter?',context);assert.equal(unknown.known,false);assert.match(unknown.text,/do not have a verified answer/);
 for(const query of ['hi','toner','membership','shipping','returns','ingredients','routine','contact','Are you AI?','customer reviews','help'])for(const action of respond(query,context).actions)assert.ok(['section','product','cart','help','email','policy','topic','tracking'].includes(action.kind));
});
test('full-sentence help search removes question words and matches useful synonyms',()=>{
 assert.equal(matchesHelpQuestion('How do I get an ELORA Circle membership card? Choose Save my card to keep your design in this browser.', 'How can I get my member card?'),true);
 assert.equal(matchesHelpQuestion('Shipping destinations, costs, and delivery estimates will be shown before payment.', 'What are the delivery costs?'),true);
 assert.equal(matchesHelpQuestion('What are the shipping and return details? The proposed policy covers refunds.', 'Where can I get a refund?'),true);
 assert.equal(matchesHelpQuestion('How will I track my order?', 'What is my order status?'),true);
 assert.equal(matchesHelpQuestion('How do I get a membership card?', 'sunscreen SPF'),false);
 assert.equal(matchesHelpQuestion('Any help question',''),true);
});
