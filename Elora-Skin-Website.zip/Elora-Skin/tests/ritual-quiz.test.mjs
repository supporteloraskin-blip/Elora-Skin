import test from 'node:test';
import assert from 'node:assert/strict';
import {quizQuestions,buildQuizResult} from '../lib/ritual-quiz.mjs';

test('incomplete or unknown preferences never produce a result',()=>{
 for(const value of [null,[],{},'dry',{feel:'dry',response:'comfortable',goal:'radiance',pace:'extra',moment:'invalid'}])assert.equal(buildQuizResult(value),null);
});

test('every valid path stays within the original concept catalog and sun-care boundaries',()=>{
 let count=0;
 const walk=(index,answers)=>{
  if(index<quizQuestions.length){const q=quizQuestions[index];for(const option of q.options)walk(index+1,{...answers,[q.id]:option.value});return;}
  const before=JSON.stringify(answers);const result=buildQuizResult(answers);count++;
  assert.ok(result);assert.equal(JSON.stringify(answers),before);
  assert.equal(new Set(result.productIds).size,result.productIds.length);
  assert.ok(result.productIds.every(id=>['cleanser','cream','serum'].includes(id)));
  assert.equal(result.productIds.includes('serum'),answers.response==='comfortable'&&answers.goal==='radiance'&&answers.pace==='extra');
  assert.equal(result.cautious,answers.response!=='comfortable');
  assert.equal(!!result.sunCare,answers.moment!=='evening');
  assert.match(result.notes.join(' '),/not a diagnosis or a tested product match/);
  if(result.sunCare)assert.match(result.sunCare,/untested concept/);
 };
 walk(0,{});assert.equal(count,270);
});

test('answers are translated into intentions, not a diagnosed skin-type label',()=>{
 const result=buildQuizResult({feel:'dry',response:'reactive',goal:'radiance',pace:'extra',moment:'both'});
 assert.deepEqual(result.productIds,['cleanser','cream']);
 assert.equal(result.title,'A quieter place to begin.');
 assert.ok(result.chips.includes('A little of both'));
 assert.match(result.notes[1],/Organic ingredients can still irritate/);
});
