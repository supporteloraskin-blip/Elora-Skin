import fs from 'node:fs';
import path from 'node:path';
import './sync-store-policies.mjs';
import './sync-quiz.mjs';
import {learningGuideMarkup} from './learning-guide-markup.mjs';
import {syncMobileShopping} from './sync-mobile-shopping.mjs';
syncMobileShopping();
const root=process.cwd();
const data=JSON.parse(fs.readFileSync(path.join(root,'content/ingredient-concepts.json'),'utf8'));
const escape=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let html=fs.readFileSync(path.join(root,'source/store.html'),'utf8');
if(html.includes('<!-- ELORA_LEARNING_GUIDE_START -->'))html=html.replace(/<!-- ELORA_LEARNING_GUIDE_START -->[\s\S]*?<!-- ELORA_LEARNING_GUIDE_END -->/,learningGuideMarkup);
else {
 const ritual=/(<section\b[^>]*\bid="ritual"[\s\S]*?)(<\/section>)/;
 if(!ritual.test(html))throw new Error('The ritual section is missing.');
 html=html.replace(ritual,(_,body,close)=>body+'\n'+learningGuideMarkup+'\n'+close);
}
let cards='';let plannedCards='';
for(const [id,product] of Object.entries(data.products)){
 const names=product.ingredients.map(key=>data.botanicals[key]);
 const markup=`<article class="ingredient-concept" id="ingredients-${id}"><div class="ingredient-card-top"><span class="eyebrow">${escape(product.number)} / INGREDIENT DIRECTION</span><span class="concept-label">Concept</span></div><h3>${escape(product.name)}</h3><p class="ingredient-direction">${escape(product.direction)}</p><ul class="botanical-list">${names.map(ingredient=>`<li><span class="botanical-dot" aria-hidden="true"></span><span><strong>${escape(ingredient.name)}</strong><small>${escape(ingredient.kind)}</small></span></li>`).join('')}</ul><details class="ingredient-development"><summary>Formulation &amp; sourcing details <span aria-hidden="true">＋</span></summary><p>${escape(product.developmentNote)}</p><p>Sourcing goal: certified-organic grades, supported by supplier certificates and batch specifications. Product certification remains unverified.</p></details><button class="text-link" data-product="${id}" aria-haspopup="dialog">Explore this essential <span aria-hidden="true">↗</span></button></article>`;
 if(product.availability==='planned')plannedCards+=markup;else cards+=markup;
}
const guide=`<!-- INGREDIENT_GUIDE_START -->
<section class="ingredients section" id="ingredients" aria-labelledby="ingredients-title"><div class="section-heading"><div><p class="eyebrow">BOTANICALS, THOUGHTFULLY CONSIDERED</p><h2 id="ingredients-title">Botanicals,<br><em>with intention.</em></h2></div><p>Melanin-rich skin at the heart.<br>Every skin tone welcome.</p></div><div class="ingredient-intro"><span class="concept-label">Proposed ingredients</span><p>We’re exploring certified-organic grades of these botanicals for the ELORA SKIN collection. These are formulation concepts; the ingredients in the pictured bottles and the organic status of the finished products have not been verified.</p></div><div class="ingredient-grid">${cards}</div><details class="ingredient-upcoming"><summary>Ingredient plans for the four new additions <span aria-hidden="true">＋</span></summary><div class="ingredient-grid">${plannedCards}</div></details><details class="ingredient-transparency"><summary>How this becomes a finished formula <span aria-hidden="true">＋</span></summary><div class="formulation-brief"><p class="eyebrow">OUR FORMULATION BRIEF</p><h3>Organic botanicals.<br>Care with <em>intention.</em></h3><p>${escape(data.skinTypesGoal)}</p><ul>${data.formulationGoals.map(goal=>`<li>${escape(goal)}</li>`).join('')}</ul><p class="formulation-source">Why gentle care? Irritation can contribute to dark spots in darker skin tones. <a href="https://www.aad.org/public/everyday-care/skin-care-secrets/routine/fade-dark-spots" target="_blank" rel="noopener noreferrer">Read the AAD guidance ↗</a></p></div><p>Your manufacturer will choose the final ingredient grades and percentages, complete the cleansing or emulsifying system, and assess preservation, stability, packaging compatibility, and suitability for the intended use. The full ingredient label will be published after that work is verified.</p><p>The concept direction proposes no added fragrance or essential oils. This is a formulation preference, not a confirmed claim about an existing product.</p><p>Finished-product organic claims depend on the complete formulation and applicable certification requirements.</p><div class="ingredient-reference-links">${data.references.map(ref=>`<a href="${escape(ref.url)}" target="_blank" rel="noopener noreferrer">${escape(ref.title)} ↗</a>`).join('')}</div></details></section>
<!-- INGREDIENT_GUIDE_END -->`;
if(html.includes('<!-- INGREDIENT_GUIDE_START -->'))html=html.replace(/<!-- INGREDIENT_GUIDE_START -->[\s\S]*?<!-- INGREDIENT_GUIDE_END -->/,guide);
else html=html.replace('    <section class="philosophy"',guide+'\n    <section class="philosophy"');
const body=html.split('<body>')[1].split('</body>')[0];
fs.writeFileSync(path.join(root,'source/store.html'),html);
fs.writeFileSync(path.join(root,'app/site-content.ts'),'export const siteMarkup = '+JSON.stringify(body)+';\n');
let app=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
const conceptCode='// INGREDIENT_DATA_START\nconst ingredientConcepts='+JSON.stringify(data)+';\n// INGREDIENT_DATA_END';
if(app.includes('// INGREDIENT_DATA_START'))app=app.replace(/\/\/ INGREDIENT_DATA_START[\s\S]*?\/\/ INGREDIENT_DATA_END/,conceptCode);
else app=app.replace('const money=amount=>',conceptCode+'\nconst money=amount=>');
fs.writeFileSync(path.join(root,'public/app.js'),app);
console.log('Synced eight ingredient concepts to the guide, product data, and server markup.');
