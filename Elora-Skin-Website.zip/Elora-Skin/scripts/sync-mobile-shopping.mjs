import fs from 'node:fs';
import path from 'node:path';

// Canonical markup is kept here so the generated home page and standalone
// export share the same controls. Existing app.js data handlers own dialogs.
export const mobileShoppingMarkup = `<!-- MOBILE_SHOPPING_START -->
<section class="mobile-shopping" id="mobile-shopping" aria-labelledby="mobile-shopping-title"><p class="eyebrow">ELORA, ON THE GO</p><h2 id="mobile-shopping-title">Your ritual,<br><em>within reach.</em></h2><p class="mobile-shopping-intro">Explore the collection, find your kind of ritual, and keep your ELORA Circle card close.</p><div class="mobile-shopping-actions"><a class="mobile-shopping-card" href="#collection"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" aria-hidden="true"><path d="M5 7h14l1 14H4L5 7Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/></svg><strong>Explore the<br>collection.</strong><small>Meet your essentials <span aria-hidden="true">↗</span></small></a><a class="mobile-shopping-card" href="#skin-quiz"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" aria-hidden="true"><path d="m12 3 2.4 6.6L21 12l-6.6 2.4L12 21l-2.4-6.6L3 12l6.6-2.4L12 3Z"/></svg><strong>Find your<br>ritual.</strong><small>Take the skin quiz <span aria-hidden="true">↗</span></small></a></div><div class="mobile-shopping-support"><a href="#membership"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M6 10h6M6 14h10"/></svg>Your Circle card <span aria-hidden="true">↗</span></a><button type="button" data-open-chat aria-haspopup="dialog" aria-controls="chat-dialog"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" aria-hidden="true"><path d="M20 11a8 8 0 0 1-8 8H6l-4 3 1.5-6A8 8 0 1 1 20 11Z"/><path d="M7 10h8M7 14h5"/></svg>Ask ELORA <span aria-hidden="true">↗</span></button></div></section>
<!-- MOBILE_SHOPPING_END -->`;

export const mobileNavigationMarkup = `<!-- MOBILE_NAV_START -->
<nav class="mobile-shop-nav" id="mobile-shop-nav" aria-label="Mobile shopping shortcuts"><a href="#collection"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M5 7h14l1 14H4L5 7Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/></svg><span>Shop</span></a><a href="#skin-quiz"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="m12 3 2.4 6.6L21 12l-6.6 2.4L12 21l-2.4-6.6L3 12l6.6-2.4L12 3Z"/></svg><span>Skin quiz</span></a><a href="#membership"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M6 10h6M6 14h10"/></svg><span>Circle</span></a><button type="button" data-open-help aria-haspopup="dialog" aria-controls="help-dialog"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 .2c0 1.8-2.5 1.8-2.5 3.8M12 16h.01"/></svg><span>Help</span></button></nav>
<!-- MOBILE_NAV_END -->`;

export const helpChatShortcut = '<button type="button" data-open-chat aria-haspopup="dialog" aria-controls="chat-dialog">Ask ELORA Concierge ↗</button>';

export function syncMobileShopping(root = process.cwd()) {
  const file=path.join(root,'source/store.html');
  let html=fs.readFileSync(file,'utf8');
  if(html.includes('<!-- MOBILE_SHOPPING_START -->')) html=html.replace(/<!-- MOBILE_SHOPPING_START -->[\s\S]*?<!-- MOBILE_SHOPPING_END -->/,mobileShoppingMarkup);
  else {
    const marker='<section class="skin-quiz section"';
    if(!html.includes(marker)) throw new Error('The skin quiz insertion anchor is missing.');
    html=html.replace(marker,mobileShoppingMarkup+'\n    '+marker);
  }
  if(html.includes('<!-- MOBILE_NAV_START -->')) html=html.replace(/<!-- MOBILE_NAV_START -->[\s\S]*?<!-- MOBILE_NAV_END -->/,mobileNavigationMarkup);
  else html=html.replace('</body>',mobileNavigationMarkup+'\n</body>');
  if(!html.includes('href="mobile-shopping.css"')) html=html.replace('<link rel="stylesheet" href="quiz.css">','<link rel="stylesheet" href="quiz.css">\n  <link rel="stylesheet" href="mobile-shopping.css">');
  if(!html.includes(helpChatShortcut)) html=html.replace('<div class="help-shortcuts">','<div class="help-shortcuts">'+helpChatShortcut);
  fs.writeFileSync(file,html);
  return html;
}

if(process.argv[1] && path.resolve(process.argv[1])===path.resolve(new URL(import.meta.url).pathname)) {
  syncMobileShopping();
  console.log('Synced the phone shopping section and mobile shortcut navigation.');
}
