export const learningGuideMarkup = `<!-- ELORA_LEARNING_GUIDE_START -->
<details class="learning-guide" id="learn" data-learning-guide>
  <summary class="learning-guide-summary">
    <span class="learning-guide-mark" aria-hidden="true">E</span>
    <span class="learning-guide-heading"><span class="learning-guide-eyebrow">THE ELORA NOTES</span><strong>Learn a little. Choose with confidence.</strong><span class="learning-guide-intro">Three thoughtful starting points, at your own pace.</span></span>
    <span class="learning-guide-toggle" aria-hidden="true"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor"><path d="M10 4v12M4 10h12"/></svg></span>
  </summary>
  <div class="learning-guide-topics">
    <details class="learning-topic" name="elora-learning-topic">
      <summary><span class="learning-topic-number" aria-hidden="true">01</span><span>Build a simple routine</span><span class="learning-topic-toggle" aria-hidden="true">＋</span></summary>
      <div class="learning-topic-copy"><p>Begin with a moment you can make time for. Use the planner above to choose morning or evening and set your pace. Then use the quiz to compare ELORA concepts through your preferences, rather than feeling you need every step.</p><a href="#skin-quiz">Find your starting point <span aria-hidden="true">↗</span></a></div>
    </details>
    <details class="learning-topic" name="elora-learning-topic">
      <summary><span class="learning-topic-number" aria-hidden="true">02</span><span>Read the label</span><span class="learning-topic-toggle" aria-hidden="true">＋</span></summary>
      <div class="learning-topic-copy"><p>Look beyond the botanical featured on the front. Read a finished product’s complete ingredient list and directions together. ELORA’s ingredient guide currently shares proposed botanicals for each concept; it is a place to explore our direction while final formula labels are being developed.</p><a href="#ingredients">Explore the ingredient guide <span aria-hidden="true">↗</span></a></div>
    </details>
    <details class="learning-topic" name="elora-learning-topic">
      <summary><span class="learning-topic-number" aria-hidden="true">03</span><span>Confidence at every stage</span><span class="learning-topic-toggle" aria-hidden="true">＋</span></summary>
      <div class="learning-topic-copy"><p>Choose one thing you enjoy about caring for yourself: a quiet evening, an unhurried morning, or keeping things simple. Let that guide what you explore. With melanin-rich skin at its heart and every skin tone welcome, ELORA celebrates caring for yourself and aging gracefully.</p><a href="#collection">Explore at your own pace <span aria-hidden="true">↗</span></a></div>
    </details>
  </div>
</details>
<!-- ELORA_LEARNING_GUIDE_END -->`;
