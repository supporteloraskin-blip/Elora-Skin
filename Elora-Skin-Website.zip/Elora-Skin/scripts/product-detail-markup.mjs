/** Full product dialog replacement. All IDs used by public/app.js are retained. */
export const productDetailMarkup = `
<dialog id="product-dialog" class="product-detail-dialog" aria-labelledby="dialog-title" aria-describedby="dialog-commerce-state">
  <button type="button" class="dialog-close" aria-label="Close product details">×</button>
  <div class="product-detail-layout">
    <figure class="product-detail-visual">
      <p class="eyebrow">THE ELORA COLLECTION</p>
      <div id="dialog-product-image" class="dialog-product-image" role="img" aria-label="ELORA packaging concept"></div>
      <figcaption><p class="dialog-packaging" id="dialog-packaging"></p><span>Packaging shown is a visual concept.</span></figcaption>
    </figure>
    <div class="product-detail-copy">
      <span class="dialog-concept-status" id="dialog-concept-status">Product concept</span>
      <p class="eyebrow" id="dialog-kicker"></p>
      <h2 id="dialog-title"></h2>
      <p class="dialog-description" id="dialog-description"></p>
      <p class="dialog-price" id="dialog-price"></p>
      <button class="button" id="dialog-add">Add to cart <span aria-hidden="true">＋</span></button>
      <p class="dialog-commerce-state" id="dialog-commerce-state">Preview cart · no payment or order is created.</p>
      <div class="product-detail-accordions">
        <details class="product-detail-accordion" open>
          <summary>Ingredient direction <span aria-hidden="true">＋</span></summary>
          <section class="dialog-ingredient-concept" aria-labelledby="dialog-ingredients-title">
            <p class="eyebrow">PROPOSED BOTANICALS</p>
            <h3 id="dialog-ingredients-title">Ingredient concept</h3>
            <ul id="dialog-ingredient-list"></ul>
            <p class="ingredient-concept-note">These proposed botanicals are a starting point for formulation, not a complete or verified ingredient list.</p>
            <a class="text-link" id="dialog-ingredients-link" href="#ingredients">Read the ingredient guide <span aria-hidden="true">↗</span></a>
          </section>
        </details>
        <details class="product-detail-accordion">
          <summary>Development &amp; availability <span aria-hidden="true">＋</span></summary>
          <div class="product-verification-copy">
            <p id="dialog-development-note" class="ingredient-concept-note"></p>
            <dl class="product-verification-list"><div><dt>Finished formula</dt><dd>Not yet verified</dd></div><div><dt>Organic certification</dt><dd>Pending verification</dd></div><div><dt>Skin-type suitability</dt><dd>Testing required</dd></div></dl>
            <div class="dialog-note"><span>THE ELORA COLLECTION</span><p>Online shopping is coming soon. Ingredient lists, directions, and confirmed prices will be available with the shop.</p></div>
          </div>
        </details>
      </div>
      <a class="text-link dialog-ritual" href="#ritual" id="dialog-ritual">Explore the ritual <span aria-hidden="true">↗</span></a>
    </div>
  </div>
</dialog>`;
export default productDetailMarkup;
