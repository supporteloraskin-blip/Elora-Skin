import fs from 'node:fs';
import path from 'node:path';
import {policyDialog} from './policy-markup.mjs';

const root=process.cwd();
const output=process.argv[2];
if(!output||!path.isAbsolute(output))throw new Error('Pass an absolute output HTML path.');
let html=fs.readFileSync(path.join(root,'source/store.html'),'utf8');
for(const name of ['styles.css','storefront.css','policies.css','quiz.css','reviews.css','mobile-shopping.css','ritual-guide.css','learning-guide.css','product-detail.css','editorial.css']){
  html=html.replace(`<link rel="stylesheet" href="${name}">`,`<style>${fs.readFileSync(path.join(root,'public',name),'utf8')}</style>`);
}
html=html.replace('<script src="app.js" defer></script>','');
for(const name of ['concierge-answers.js','reviews.js','product-detail.js','ritual-guide.js','learning-guide.js','experience.js'])html=html.replace(`<script src="${name}" defer></script>`,'');
const policies=JSON.parse(fs.readFileSync(path.join(root,'content/store-policies.json'),'utf8'));
for(const kind of ['shipping','returns']){
  html=html.replaceAll(`href="/policies/${kind}"`,`href="#offline-policy-${kind}" data-policy-open="${kind}"`);
  html=html.replace('</body>',policyDialog(kind,policies)+'</body>');
}
const mediaTypes={'.otf':'font/otf','.webp':'image/webp','.png':'image/png','.svg':'image/svg+xml'};
const images={};
html=html.replace(/<link rel="preload" href="assets\/[^"]+" as="image">/g,'');
for(const name of fs.readdirSync(path.join(root,'public/assets'))){
  const reference='assets/'+name;
  if(!html.includes(reference))continue;
  const type=mediaTypes[path.extname(name)];
  if(!type)throw new Error('Unknown asset type: '+name);
  const data='data:'+type+';base64,'+fs.readFileSync(path.join(root,'public/assets',name)).toString('base64');
  if(type==='image/png'||type==='image/webp'){
    images[reference]=data;
    html=html.replaceAll(`src="${reference}"`,`data-embedded-image="${reference}"`);
    html=html.replaceAll(`href="${reference}"`,`data-embedded-image="${reference}"`);
  }else html=html.split(reference).join(data);
}
// Keep each large photograph once while reusing it in the hero and product views.
const loader=`(()=>{const images=${JSON.stringify(images)};for(const [reference,data]of Object.entries(images)){for(const element of document.querySelectorAll('[data-embedded-image]')){if(element.dataset.embeddedImage!==reference)continue;element.setAttribute(element.tagName.toLowerCase()==='image'?'href':'src',data)}}})();`;
html=html.replace('</body>',`<script>${loader}</script><script>${fs.readFileSync(path.join(root,'public/concierge-answers.js'),'utf8')}</script><script>${fs.readFileSync(path.join(root,'public/app.js'),'utf8')}</script><script>${fs.readFileSync(path.join(root,'public/reviews.js'),'utf8')}</script>${['product-detail.js','ritual-guide.js','learning-guide.js','experience.js'].map(name=>'<script>'+fs.readFileSync(path.join(root,'public',name),'utf8')+'</script>').join('')}</body>`);
if(/(?:src|href)="(?:styles\.css|storefront\.css|policies\.css|quiz\.css|reviews\.css|mobile-shopping\.css|ritual-guide\.css|learning-guide\.css|product-detail\.css|editorial\.css|concierge-answers\.js|reviews\.js|ritual-guide\.js|learning-guide\.js|product-detail\.js|experience\.js|app\.js|assets\/)/.test(html))throw new Error('Review export has an unresolved local asset.');
fs.mkdirSync(path.dirname(output),{recursive:true});
fs.writeFileSync(output,html);
process.stdout.write(`Exported ${path.basename(output)} (${Buffer.byteLength(html)} bytes)\n`);
