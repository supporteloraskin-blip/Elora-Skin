import { getCustomerReviewFeed } from '../../../lib/reviews';
export const dynamic = 'force-dynamic';
export async function GET() {
  return Response.json(await getCustomerReviewFeed(), { headers: { 'Cache-Control': 'no-store' } });
}
