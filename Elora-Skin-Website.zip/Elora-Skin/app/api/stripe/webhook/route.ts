import { env } from 'cloudflare:workers';
import { getDb } from '../../../../db';
import { orders } from '../../../../db/schema';
import { shopJson } from '../../../../lib/shop';
import { readBoundedBody, decodeRequestBody, RequestBodyError } from '../../../../lib/request-body';
export const dynamic='force-dynamic';
function same(a:string,b:string){if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0;}
export async function POST(request:Request){
 if(!env.STRIPE_WEBHOOK_SECRET)return shopJson({error:'Webhook not configured.'},503);
 let body:Uint8Array;try{body=await readBoundedBody(request,1048576)}catch(error){if(error instanceof RequestBodyError&&error.code==='payload_too_large')return shopJson({error:'Payload too large.',code:'payload_too_large'},413);return shopJson({error:'Invalid event.'},400)}
 const signature=request.headers.get('stripe-signature')||'';const parts=signature.split(',').map(x=>x.trim().split('='));const timestamp=parts.find(([k])=>k==='t')?.[1];const signatures=parts.filter(([k,v])=>k==='v1'&&typeof v==='string'&&/^[a-f0-9]{64}$/i.test(v)).map(([,v])=>v.toLowerCase());
 if(!timestamp||!/^\d+$/.test(timestamp)||Math.abs(Date.now()/1000-Number(timestamp))>300)return shopJson({error:'Invalid signature.'},400);
 const prefix=new TextEncoder().encode(timestamp+'.');const signedBytes=new Uint8Array(prefix.byteLength+body.byteLength);signedBytes.set(prefix);signedBytes.set(body,prefix.byteLength);
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(env.STRIPE_WEBHOOK_SECRET),{name:'HMAC',hash:'SHA-256'},false,['sign']);const digest=await crypto.subtle.sign('HMAC',key,signedBytes);const expected=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');
 if(!signatures.some(v=>same(v,expected)))return shopJson({error:'Invalid signature.'},400);
 let event:any;try{event=JSON.parse(decodeRequestBody(body))}catch{return shopJson({error:'Invalid event.'},400)}
 if(!event||typeof event!=='object'||Array.isArray(event))return shopJson({error:'Invalid event.'},400);
 if(!['checkout.session.completed','checkout.session.async_payment_succeeded','checkout.session.async_payment_failed'].includes(event.type))return shopJson({received:true});
 const session=event.data?.object;if(!session?.id||typeof session.id!=='string')return shopJson({error:'Invalid session.'},400);
 // Ignore unpaid completion and failure events. Never downgrade an already paid session.
 if(session.payment_status!=='paid')return shopJson({received:true});
 try{const values={sessionId:session.id,userId:session.metadata?.elora_user_id||null,paymentStatus:'paid',amountTotal:session.amount_total||0,currency:session.currency||'usd'};await getDb().insert(orders).values(values).onConflictDoUpdate({target:orders.sessionId,set:{paymentStatus:'paid',amountTotal:values.amountTotal,currency:values.currency}});return shopJson({received:true});}
 catch{return shopJson({error:'Please retry this payment event.'},503)}
}
