import { eq } from 'drizzle-orm';
import { getDb } from '../../../db';
import { members } from '../../../db/schema';
import { getChatGPTUser } from '../../chatgpt-auth';
import { readBoundedText, RequestBodyError } from '../../../lib/request-body';
export const dynamic='force-dynamic';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
const validId=(id:unknown)=>typeof id==='string'&&['cleanser','serum','cream','eye'].includes(id);
function sameOrigin(request:Request){const origin=request.headers.get('origin');return !origin||origin===new URL(request.url).origin;}
export async function GET(){
 const user=await getChatGPTUser();if(!user)return json({signedIn:false,member:null});
 try{const member=await getDb().select().from(members).where(eq(members.userId,user.userId)).get();return json({signedIn:true,name:user.fullName||'',member:member?{...member,userId:undefined,favorites:JSON.parse(member.favorites)}:null})}
 catch{return json({error:'Membership is temporarily unavailable. Please try again shortly.'},503)}
}
export async function POST(request:Request){
 if(!sameOrigin(request))return json({error:'Please use the ELORA website to join.'},403);
 const user=await getChatGPTUser();if(!user)return json({error:'Please sign in to create your membership.'},401);
 let value:any;try{value=JSON.parse(await readBoundedText(request,4096))}catch(error){if(error instanceof RequestBodyError&&error.code==='payload_too_large')return json({error:'The request is too large.',code:'payload_too_large'},413);return json({error:'Please check your name.'},400)}
 if(!value||typeof value!=='object'||Array.isArray(value))return json({error:'Please check your name.'},400);
 const displayName=typeof value.name==='string'?value.name.trim().replace(/[\x00-\x1f]/g,'').slice(0,45):'';
 if(!displayName)return json({error:'Enter the name you would like on your card.'},400);
 const cardStyle=['olive','ivory'].includes(value.style)?value.style:'olive';
 try{const db=getDb();const memberId='ELR-'+crypto.randomUUID().replaceAll('-','').slice(0,12).toUpperCase();
  await db.insert(members).values({userId:user.userId,memberId,displayName,cardStyle}).onConflictDoNothing();
  const member=await db.select().from(members).where(eq(members.userId,user.userId)).get();
  return json({signedIn:true,member:member?{...member,userId:undefined,favorites:JSON.parse(member.favorites)}:null});
 }catch{return json({error:'We could not create your card. Please try again.'},503)}
}
export async function PATCH(request:Request){
 if(!sameOrigin(request))return json({error:'Please use the ELORA website.'},403);
 const user=await getChatGPTUser();if(!user)return json({error:'Please sign in.'},401);
 let value:any;try{value=JSON.parse(await readBoundedText(request,4096))}catch(error){if(error instanceof RequestBodyError&&error.code==='payload_too_large')return json({error:'The request is too large.',code:'payload_too_large'},413);return json({error:'Invalid details.'},400)}
 if(!value||typeof value!=='object'||Array.isArray(value))return json({error:'Invalid details.'},400);
 const update:Partial<typeof members.$inferInsert>={};
 if(typeof value.name==='string'){const name=value.name.trim().replace(/[\x00-\x1f]/g,'').slice(0,45);if(!name)return json({error:'Enter a name for your card.'},400);update.displayName=name;}
 if(['olive','ivory'].includes(value.style))update.cardStyle=value.style;
 if(Array.isArray(value.favorites))update.favorites=JSON.stringify([...new Set(value.favorites.filter(validId))].slice(0,4));
 if(['morning','evening'].includes(value.moment))update.moment=value.moment;
 if(!Object.keys(update).length)return json({error:'No changes to save.'},400);
 try{const member=await getDb().update(members).set(update).where(eq(members.userId,user.userId)).returning().get();if(!member)return json({error:'Create your free membership first.'},404);return json({member:{...member,userId:undefined,favorites:JSON.parse(member.favorites)}})}
 catch{return json({error:'We could not save those changes. Please try again.'},503)}
}
export async function DELETE(request:Request){
 if(!sameOrigin(request))return json({error:'Please use the ELORA website.'},403);
 const user=await getChatGPTUser();if(!user)return json({error:'Please sign in.'},401);
 try{await getDb().delete(members).where(eq(members.userId,user.userId));return json({deleted:true})}catch{return json({error:'We could not remove your membership. Please try again.'},503)}
}
