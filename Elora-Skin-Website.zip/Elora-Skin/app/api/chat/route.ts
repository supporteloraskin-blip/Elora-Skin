import { env } from 'cloudflare:workers';
import { conciergeInstructions } from '../../../lib/concierge';
import { parseChatMessages, responseText } from '../../../lib/chat-validation';
import { reserveQuotaSql } from '../../../lib/chat-quota';
import { checkoutReady, shopJson, shopOrigin } from '../../../lib/shop';

export const dynamic = 'force-dynamic';
function ready() {
  return env.CHAT_ENABLED === 'true' && !!env.OPENAI_API_KEY && !!env.OPENAI_CHAT_MODEL && (env.CHAT_RATE_SALT?.length || 0) >= 32 && !!env.DB;
}

export async function GET() {
  return shopJson({ aiReady: ready(), name: 'ELORA Concierge', fallback: 'quick-answers' });
}

async function reserveQuota(request: Request) {
  const now = Math.floor(Date.now() / 1000);
  // Only the trusted edge-provided IP is used. No raw IP or transcript is saved.
  const address = request.headers.get('cf-connecting-ip');
  if (!address) return false;
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(env.CHAT_RATE_SALT), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const digest = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(Math.floor(now / 86400) + ':' + address));
  const visitor = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
  const buckets = [
    { key: `minute:${Math.floor(now / 60)}:${visitor}`, limit: 5, expires: now + 120 },
    { key: `day:${Math.floor(now / 86400)}:${visitor}`, limit: 25, expires: now + 90000 },
    { key: `global:${Math.floor(now / 86400)}`, limit: 100, expires: now + 90000 },
  ];
  const results = await env.DB!.batch(buckets.map(bucket => env.DB!.prepare(reserveQuotaSql).bind(bucket.key, bucket.expires, bucket.limit)));
  // The global allowance bounds provider requests even when visitors change IP.
  const accepted = results.every(result => result.success && result.results.length === 1);
  await env.DB!.prepare('DELETE FROM chat_rate_limits WHERE bucket_key IN (SELECT bucket_key FROM chat_rate_limits WHERE expires_at < ? LIMIT 100)').bind(now).run();
  return accepted;
}

export async function POST(request: Request) {
  if (request.headers.get('origin') !== shopOrigin(request)) return shopJson({ error: 'Open chat from the ELORA website.' }, 403);
  if (!request.headers.get('content-type')?.includes('application/json')) return shopJson({ error: 'Invalid chat request.' }, 400);
  if (!ready()) return shopJson({ error: 'AI is not connected yet. Quick answers and FAQs are available.', aiReady: false }, 503);
  const reader = request.body?.getReader();
  if (!reader) return shopJson({ error: 'Enter a message first.' }, 400);
  let text = ''; let bytes = 0;
  const decoder = new TextDecoder();
  while (true) {
    const part = await reader.read();
    if (part.done) break;
    bytes += part.value.byteLength;
    if (bytes > 16000) { await reader.cancel(); return shopJson({ error: 'Keep the conversation a little shorter.' }, 413); }
    text += decoder.decode(part.value, { stream: true });
  }
  text += decoder.decode();
  let value: unknown;
  try { value = JSON.parse(text); } catch { return shopJson({ error: 'Please check your message.' }, 400); }
  const messages = parseChatMessages(value);
  if (!messages) return shopJson({ error: 'Start a new chat or shorten your message.' }, 400);
  try {
    if (!await reserveQuota(request)) return shopJson({ error: 'AI chat has reached its current allowance. Quick answers and FAQs are still available.' }, 429);
    const result = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST', signal: AbortSignal.timeout(25000),
      headers: { Authorization: 'Bearer ' + env.OPENAI_API_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: env.OPENAI_CHAT_MODEL, instructions: conciergeInstructions(checkoutReady()), input: messages, max_output_tokens: 600, store: false }),
    });
    if (!result.ok) return shopJson({ error: 'AI is temporarily unavailable. Try a quick answer below or open FAQs.' }, 502);
    const answer = responseText(await result.json());
    if (!answer) return shopJson({ error: 'No answer came back. Try a quick answer or open FAQs.' }, 502);
    return shopJson({ answer, source: 'ai' });
  } catch {
    return shopJson({ error: 'AI is temporarily unavailable. Your message has not been saved by ELORA. Quick answers are available.' }, 503);
  }
}
