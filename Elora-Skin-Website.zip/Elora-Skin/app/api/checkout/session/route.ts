import { env } from 'cloudflare:workers';
import { shopJson } from '../../../../lib/shop';
export const dynamic='force-dynamic';
export async function GET(request:Request){
 const id=new URL(request.url).searchParams.get('session_id');if(!id||!/^cs_(test_|live_)?[A-Za-z0-9_]+$/.test(id))return shopJson({error:'We couldn’t find that checkout session.'},400);
 if(!env.STRIPE_SECRET_KEY)return shopJson({error:'Payment confirmation is not connected yet.'},503);
 try{const result=await fetch('https://api.stripe.com/v1/checkout/sessions/'+encodeURIComponent(id),{headers:{Authorization:'Bearer '+env.STRIPE_SECRET_KEY}});if(!result.ok)return shopJson({error:'We couldn’t confirm that payment. Please check your payment receipt.'},404);const session:any=await result.json();return shopJson({paid:session.payment_status==='paid',status:session.status,amount:session.amount_total,currency:session.currency,reference:session.id.slice(-10).toUpperCase()});}
 catch{return shopJson({error:'Payment confirmation is temporarily unavailable. Please check your receipt before trying again.'},503)}
}
