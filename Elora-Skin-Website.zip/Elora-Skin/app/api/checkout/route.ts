import { env } from 'cloudflare:workers';
import { catalog, checkoutReady, shopJson, shopOrigin } from '../../../lib/shop';
import { getChatGPTUser } from '../../chatgpt-auth';
import { getDb } from '../../../db';
import { orders } from '../../../db/schema';
import { commerceStatus } from '../../../lib/commerce';
import { readBoundedText, RequestBodyError } from '../../../lib/request-body';
export const dynamic='force-dynamic';
export async function POST(request:Request){
 if(request.headers.get('origin')&&request.headers.get('origin')!==shopOrigin(request))return shopJson({error:'Please check out from the ELORA website.'},403);
 if(!request.headers.get('content-type')?.includes('application/json'))return shopJson({error:'Invalid checkout request.'},400);
 let value:any;try{value=JSON.parse(await readBoundedText(request,4096))}catch(error){if(error instanceof RequestBodyError&&error.code==='payload_too_large')return shopJson({error:'Your cart is too large.',code:'payload_too_large'},413);return shopJson({error:'Please check your cart.'},400)}
 if(!value||typeof value!=='object'||!Array.isArray(value.items)||!value.items.length||value.items.length>4)return shopJson({error:'Add an essential to your cart first.'},400);
 const quantities=new Map<string,number>();
 for(const item of value.items){if(!item||typeof item!=='object'||typeof item.id!=='string'||!Object.hasOwn(catalog,item.id)||!Number.isInteger(item.quantity)||item.quantity<1||item.quantity>20)return shopJson({error:'Please check the products and quantities in your cart.'},400);quantities.set(item.id,(quantities.get(item.id)||0)+item.quantity);}
 if([...quantities.values()].some(q=>q>20))return shopJson({error:'Choose no more than 20 of each essential.'},400);
 if(!checkoutReady())return shopJson({error:'Secure checkout is being connected. Your selections are saved; no order or payment has been made.'},503);
 const commerce=commerceStatus(env);
 // Squarespace owns its cart, payment and native Selfnamed integration. Do not
 // invent a cross-site cart transfer or forward unverified orders to a vendor.
 if(commerce.provider==='squarespace')return shopJson({url:commerce.storeUrl,provider:'squarespace',cartTransferred:false});
 const origin=shopOrigin(request);const params=new URLSearchParams({mode:'payment',success_url:origin+'/checkout?session_id={CHECKOUT_SESSION_ID}',cancel_url:origin+'/#collection',billing_address_collection:'required','automatic_tax[enabled]':'true'});
 let i=0;for(const [id,quantity]of quantities){const product=catalog[id as keyof typeof catalog];params.set(`line_items[${i}][price_data][currency]`,'usd');params.set(`line_items[${i}][price_data][unit_amount]`,String(product.price));params.set(`line_items[${i}][price_data][product_data][name]`,product.name);params.set(`line_items[${i}][quantity]`,String(quantity));i++;}
 const countries=(env.SHIPPING_COUNTRIES||'').split(',').map(x=>x.trim().toUpperCase()).filter(x=>/^[A-Z]{2}$/.test(x));if(!countries.length)return shopJson({error:'Shipping is being finalized.'},503);
 countries.forEach((c,index)=>params.set(`shipping_address_collection[allowed_countries][${index}]`,c));
 params.set('shipping_options[0][shipping_rate_data][type]','fixed_amount');params.set('shipping_options[0][shipping_rate_data][fixed_amount][amount]',env.SHIPPING_AMOUNT_CENTS!);params.set('shipping_options[0][shipping_rate_data][fixed_amount][currency]','usd');params.set('shipping_options[0][shipping_rate_data][display_name]','Shipping');
 const user=await getChatGPTUser();if(user)params.set('metadata[elora_user_id]',user.userId);
 try{const response=await fetch('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers:{Authorization:'Bearer '+env.STRIPE_SECRET_KEY,'Content-Type':'application/x-www-form-urlencoded','Idempotency-Key':crypto.randomUUID()},body:params});const session:any=await response.json();
 if(!response.ok||!session.url)return shopJson({error:'We couldn’t open secure checkout. Your cart is still saved. Please try again shortly.'},502);
 // Record a pending session; only a verified payment event can mark it paid.
 await getDb().insert(orders).values({sessionId:session.id,userId:user?.userId||null,paymentStatus:'pending',amountTotal:session.amount_total||0}).onConflictDoNothing();
 return shopJson({url:session.url});
 }catch{return shopJson({error:'Checkout is temporarily unavailable. No payment was taken here.'},502)}
}
