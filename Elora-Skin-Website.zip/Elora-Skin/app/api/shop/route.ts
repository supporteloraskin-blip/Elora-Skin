import { catalog, upcomingCatalog, checkoutReady, shopJson } from '../../../lib/shop';
import { env } from 'cloudflare:workers';
import { commerceStatus } from '../../../lib/commerce';
export const dynamic='force-dynamic';
export async function GET(){return shopJson({products:catalog,upcomingProducts:upcomingCatalog,currency:'usd',pricesApproved:checkoutReady(),checkoutReady:checkoutReady(),commerce:commerceStatus(env)})}
