import policies from '../../content/store-policies.json';

export default function PolicyPage({kind}: {kind: 'shipping' | 'returns'}) {
  const policy = policies[kind];
  const other = kind === 'shipping' ? 'returns' : 'shipping';
  return <div className="policy-page">
    <a href="#policy-main" className="skip">Skip to policy</a>
    <div className="announcement">{policies.notice}</div>
    <header className="policy-header">
      <a className="wordmark" href="/" aria-label="ELORA SKIN home"><span>ELORA</span><small>SKIN</small></a>
      <nav aria-label="Policy navigation"><a href="/">Back to the store <span aria-hidden="true">↗</span></a><a href="/track-order">Track your order <span aria-hidden="true">↗</span></a><a href={'/policies/' + other}>{policies[other].label}</a></nav>
    </header>
    <main id="policy-main" className="policy-main">
      <div className="policy-breadcrumb"><a href="/">ELORA SKIN</a><span aria-hidden="true">/</span><span>{policy.label}</span></div>
      <section className="policy-hero" aria-labelledby="policy-title">
        <p className="eyebrow">SHOP WITH CLARITY</p><h1 id="policy-title">{policy.title}</h1><p className="policy-lead">{policy.lead}</p>
        <div className="policy-notice"><span className="policy-draft-label">Draft · not yet effective</span><p>{policies.launchNote}</p></div>
        <dl className="policy-highlights">{policy.highlights.map(item => <div key={item.label}><dt>{item.value}</dt><dd>{item.label}</dd></div>)}</dl>
      </section>
      <div className="policy-layout"><aside className="policy-toc"><p className="eyebrow">IN THIS POLICY</p><nav aria-label="On this page">{policy.sections.map((section, i) => <a key={section.id} href={'#'+section.id}><span>{String(i+1).padStart(2,'0')}</span>{section.title}</a>)}</nav></aside>
        <article className="policy-content">{policy.sections.map((section, i) => <section key={section.id} id={section.id}><span className="policy-section-number">{String(i+1).padStart(2,'0')}</span><h2>{section.title}</h2>{section.paragraphs.map(paragraph => <p key={paragraph}>{paragraph}</p>)}</section>)}
          <div className="policy-support"><p className="eyebrow">A LITTLE MORE GUIDANCE</p><h2>We’re here for your<br/><em>next question.</em></h2><p>Email supporteloraskin@gmail.com for customer care. No return request or customer order is submitted from this draft.</p><div><a className="button" href="mailto:supporteloraskin@gmail.com">Email ELORA <span aria-hidden="true">↗</span></a><a className="text-link" href={'/policies/'+other}>{policies[other].label} <span aria-hidden="true">↗</span></a></div></div>
        </article>
      </div>
    </main>
    <footer className="policy-footer"><a href="/">← Back to ELORA SKIN</a><span>Timeless care. Clear terms.</span></footer>
  </div>;
}
