import type { Metadata } from 'next';
import PolicyPage from '../policy-page';
export const metadata: Metadata = {alternates: {canonical: "/policies/shipping"}, title: 'Shipping Policy | ELORA SKIN', description: 'ELORA SKIN’s draft shipping policy: destinations, delivery charges, processing, tracking and delivery support.'};
export default function ShippingPolicy(){return <PolicyPage kind="shipping"/>;}
