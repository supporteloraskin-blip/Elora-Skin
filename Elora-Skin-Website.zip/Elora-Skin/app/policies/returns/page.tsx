import type { Metadata } from 'next';
import PolicyPage from '../policy-page';
export const metadata: Metadata = {alternates: {canonical: "/policies/returns"}, title: 'Return Policy | ELORA SKIN', description: 'ELORA SKIN’s draft return and refund policy, including unopened products and damaged or incorrect items.'};
export default function ReturnPolicy(){return <PolicyPage kind="returns"/>;}
