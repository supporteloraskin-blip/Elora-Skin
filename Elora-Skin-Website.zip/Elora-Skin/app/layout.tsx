import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  metadataBase: new URL('https://elora-skin-ritual.cherryloom20.chatgpt.site'),
  title: 'ELORA SKIN — Timeless Care & Everyday Luxury',
  description: 'Timeless care, thoughtful rituals, and everyday confidence. Explore ELORA SKIN’s pre-launch collection, ingredient direction, skin quiz, and free digital Circle card.',
  alternates: { canonical: '/' },
  openGraph: {
    type: 'website', locale: 'en_US', siteName: 'ELORA SKIN', url: '/',
    title: 'ELORA SKIN — Your Skin. Your Season. Your Ritual.',
    description: 'Melanin-rich skin at the heart. Every skin tone welcome. Explore our next chapter in timeless care.',
    images: [{ url: '/assets/elora-ritual-gold-v3.png', width: 1671, height: 941, alt: 'ELORA SKIN pre-launch packaging concepts in ivory, olive, and gold' }],
  },
  twitter: { card: 'summary_large_image', title: 'ELORA SKIN — Timeless Care', images: ['/assets/elora-ritual-gold-v3.png'] },
  icons: { icon: '/assets/favicon.svg' },
};
export default function RootLayout({children}: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><head><meta name="theme-color" content="#52634e"/><link rel="stylesheet" href="/styles.css"/><link rel="stylesheet" href="/storefront.css"/><link rel="stylesheet" href="/policies.css"/><link rel="stylesheet" href="/quiz.css"/><link rel="stylesheet" href="/reviews.css"/><link rel="stylesheet" href="/mobile-shopping.css"/><link rel="stylesheet" href="/ritual-guide.css"/><link rel="stylesheet" href="/learning-guide.css"/><link rel="stylesheet" href="/product-detail.css"/><link rel="stylesheet" href="/editorial.css"/><link rel="preload" href="/assets/elora-ritual-gold-v3.png" as="image"/></head><body>{children}</body></html>;
}
