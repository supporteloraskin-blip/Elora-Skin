import type { Metadata } from 'next';
import { AFTERSHIP_TRACKING_URL } from '../../lib/tracking';
import './tracking.css';

export const metadata: Metadata = {
  title: 'Track Your Order | ELORA SKIN',
  description: 'Follow your ELORA shipment with our AfterShip order and tracking-number lookup.',
  alternates: { canonical: '/track-order' },
  openGraph: { title: 'Track Your Order | ELORA SKIN', description: 'A clear view of your shipment, from dispatch to delivery.', url: '/track-order' },
};

export default function TrackOrderPage() {
  return <div className="tracking-page">
    <a className="skip" href="#tracking-main">Skip to order tracking</a>
    <div className="announcement">ELORA SKIN · TIMELESS CARE</div>
    <header className="policy-header tracking-header">
      <a className="wordmark" href="/" aria-label="ELORA SKIN home"><span>ELORA</span><small>SKIN</small></a>
      <nav aria-label="Tracking navigation"><a href="/">Back to ELORA <span aria-hidden="true">↗</span></a><a href="mailto:supporteloraskin@gmail.com">Customer care <span aria-hidden="true">↗</span></a></nav>
    </header>
    <main id="tracking-main" className="tracking-main">
      <section className="tracking-intro" aria-labelledby="tracking-title">
        <p className="eyebrow">YOUR ELORA JOURNEY</p>
        <h1 id="tracking-title">Track your <em>order.</em></h1>
        <p>Use your order number and checkout email, or choose your tracking number, to follow your parcel.</p>
      </section>
      <section className="tracking-panel" aria-label="ELORA shipment lookup">
        <div className="tracking-panel-bar"><span>SHIPMENT TRACKING · AFTERSHIP</span><a href={AFTERSHIP_TRACKING_URL} target="_blank" rel="noopener noreferrer">Open tracking page <span aria-hidden="true">↗</span><span className="sr-only"> (opens in a new tab)</span></a></div>
        <iframe className="tracking-frame" src={AFTERSHIP_TRACKING_URL} title="Track your ELORA SKIN order with AfterShip" referrerPolicy="strict-origin-when-cross-origin" />
        <p className="tracking-provider-note">The tracker is provided by AfterShip. Lookup details are submitted to AfterShip. If the tracker does not load here, use <a href={AFTERSHIP_TRACKING_URL} target="_blank" rel="noopener noreferrer">Open tracking page<span className="sr-only"> (opens in a new tab)</span></a>.</p>
      </section>
      <div className="tracking-launch-note"><span aria-hidden="true">✧</span><p>ELORA is in pre-launch. Ordering on this website is not open yet. Tracking appears only for real orders and shipments sent to AfterShip by the store.</p></div>
      <section className="tracking-help" aria-labelledby="tracking-help-title">
        <div><p className="eyebrow">A LITTLE CLARITY</p><h2 id="tracking-help-title">Need a little <em>guidance?</em></h2></div>
        <div className="tracking-questions">
          <details><summary>My order is not showing <span aria-hidden="true">＋</span></summary><p>Use the order number and email from your checkout confirmation. Only orders synced from the store can appear. If you have a tracking number, try the Tracking number tab instead. Contact customer care if you still need help.</p></details>
          <details><summary>My tracking has not updated <span aria-hidden="true">＋</span></summary><p>A label can be created before a parcel reaches the carrier. Updates appear as the carrier scans your shipment. For a missing parcel, an unexpected delay, or a delivery concern, email <a href="mailto:supporteloraskin@gmail.com">supporteloraskin@gmail.com</a>.</p></details>
          <details><summary>I need to change or cancel an order <span aria-hidden="true">＋</span></summary><p>Email <a href="mailto:supporteloraskin@gmail.com">supporteloraskin@gmail.com</a> with your order reference. This tracking page does not change or cancel orders, and a change cannot be guaranteed after processing begins.</p></details>
        </div>
      </section>
      <div className="tracking-care"><span>Still need a hand?</span><a className="text-link" href="mailto:supporteloraskin@gmail.com">Email ELORA customer care <span aria-hidden="true">↗</span></a></div>
    </main>
    <footer className="policy-footer"><a href="/">← Back to ELORA SKIN</a><a href="/policies/shipping">Shipping policy</a><a href="/policies/returns">Return policy</a></footer>
  </div>;
}
