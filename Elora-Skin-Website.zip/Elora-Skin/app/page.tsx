import { siteMarkup } from './site-content';
import StoreClient from './store-client';
export const dynamic='force-dynamic';
export default function Home(){
 return <><div id="elora-root" dangerouslySetInnerHTML={{__html:siteMarkup}}/><StoreClient/></>;
}
