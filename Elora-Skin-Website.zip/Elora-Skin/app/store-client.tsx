'use client';
import { useEffect } from 'react';
export default function StoreClient(){
 useEffect(()=>{for(const [id,src] of [['elora-concierge-answers','/concierge-answers.js'],['elora-controller','/app.js'],['elora-reviews','/reviews.js'],['elora-product-detail','/product-detail.js'],['elora-ritual-guide','/ritual-guide.js'],['elora-learning-guide','/learning-guide.js'],['elora-experience','/experience.js']]){if(document.getElementById(id))continue;const script=document.createElement('script');script.id=id;script.src=src;script.async=false;document.body.appendChild(script);}},[]);
 return null;
}
