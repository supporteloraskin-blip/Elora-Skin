// The original hosting service supplied authenticated identity headers.
// An independently hosted Worker must not trust caller-supplied identity headers.
// Keep legacy account endpoints unauthenticated until a real identity provider
// is configured. The existing local ELORA Circle card does not need an account.
export type ChatGPTUser = {
  userId: string;
  displayName: string;
  email: string;
  fullName: string | null;
};

export async function getChatGPTUser(): Promise<ChatGPTUser | null> {
  return null;
}
