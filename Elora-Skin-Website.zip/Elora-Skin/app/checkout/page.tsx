'use client';
import { useEffect,useState } from 'react';
export default function Checkout(){
 const [message,setMessage]=useState('Confirming your payment…');const [reference,setReference]=useState('');
 useEffect(()=>{const id=new URLSearchParams(window.location.search).get('session_id');if(!id){setMessage('No checkout session was provided.');return;}fetch('/api/checkout/session?session_id='+encodeURIComponent(id)).then(r=>r.json()).then((data:any)=>{if(data.paid){setMessage('Thank you. Your payment is confirmed.');setReference(data.reference);localStorage.removeItem('elora-cart-v1');}else setMessage(data.error||'Your payment is still being confirmed. Please check your receipt before placing another order.');}).catch(()=>setMessage('We could not confirm your payment here. Please check your receipt before trying again.'));},[]);
 return <main className="checkout-confirm"><a className="wordmark" href="/"><span>ELORA</span><small>SKIN</small></a><p className="eyebrow">YOUR ELORA RITUAL</p><h1>{message}</h1>{reference&&<p>Payment reference: {reference}</p>}<a className="button" href="/">Return to ELORA SKIN ↗</a></main>;
}
