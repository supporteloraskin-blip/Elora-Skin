# ELORA SKIN — Product and launch readiness

Source audit: 24 October 2026. This is an owner checklist, not a product certificate. The audit inspected this project's catalog, ingredient concepts, packaging art, commerce configuration, review logic and order schema. No manufacturer account, physical product, laboratory report or live store was verified by this audit.

## What the project establishes

The website implements eight product presentations, local cart selections, digital Circle cards, a preference quiz, Help/FAQs, customer-care links, draft store policies, phone layouts and a prepared customer-review area. Those website features do not establish the contents, safety, performance, availability or certification of a physical product.

`content/ingredient-concepts.json` explicitly marks ingredients as proposed and finished-product organic certification as unverified. The listed botanical suppliers are raw-material examples, not evidence that ELORA's products contain those materials. The quiz suggests concepts; it does not diagnose skin or certify a product match.

## Eight products to match to real supplier records

| ELORA concept | Current draft offer | Packaging direction | Supplier evidence still needed |
| --- | --- | --- | --- |
| Gentle Silk Cleanser | $16 / 120 mL, proposed | Pump bottle | Actual product ID, full INCI, approved fill and pump compatibility |
| Radiance Renewal Serum | $22 / 30 mL, proposed | Dropper bottle | Actual product ID, full INCI, approved fill and dropper compatibility |
| Comfort Veil Face Cream | $23 / 50 mL, proposed | Jar | Actual product ID, full INCI, approved fill and container compatibility |
| Timeless Eye Cream | $18 / 15 mL, proposed | Airless pump bottle | Actual product ID, full INCI, eye-area assessment and airless compatibility |
| Gentle Facial Scrub | Price and size unconfirmed | Jar | Actual product ID, complete formula, particle assessment and supported use directions |
| Sunscreen | Price and size unconfirmed | Tube | Actual product ID, active UV filters, supported SPF/broad-spectrum evidence and final label |
| Cleansing Facial Pads | Price and count unconfirmed | Upright flip-top dispenser | Actual product ID, pad material/count, full cleansing-solution INCI and dispenser compatibility |
| Facial Toner | Price and size unconfirmed | Fine-mist sprayer | Actual product ID, full INCI, final directions and sprayer compatibility |

No manufacturer SKU mapping, complete finished-product INCI, product-specific test report, organic certificate, inventory feed or supplier cost sheet was found in the audited source. Local keys such as `cleanser` and `serum` are website identifiers, not manufacturer product IDs.

## Product approval checklist

- [ ] Match each of the eight concepts to an actual supplier SKU, approved design and sellable variant. Confirm the supplier can supply the pictured container, closure, gold finish, fill size and label; revise art to match reality where necessary.
- [ ] Obtain the final INCI, ingredient/allergen disclosures, directions, warnings, batch/shelf-life details and supplier safety/stability/preservation documentation for each finished product.
- [ ] Obtain evidence for every product-specific claim. Keep “organic,” “all skin types,” “fragrance-free,” eye-area suitability and performance claims qualified until supported by the finished product's records. Assess the intended audience, including melanin-rich skin; welcoming every skin tone is not proof of universal skin-type suitability.
- [ ] Approve scrub suitability and use frequency separately. Do not turn the collection's inclusive positioning into a guarantee that a scrub suits every person.
- [ ] Verify the sunscreen's actual active ingredients, tested SPF, broad-spectrum status and any water-resistance/no-white-cast claims before offering sun protection. The current sunscreen concept supplies none of that evidence.
- [ ] Confirm wholesale/production cost, merchant margin, final retail price, shipping/taxes, supported countries, availability and stock/out-of-stock handling for every variant.

## Copy and image approval

Keep packaging art visibly identified as a concept while supplier matching is incomplete. The current hero art includes proposed net contents and printed benefit phrases such as “BRIGHTEN · REPLENISH,” “HYDRATE · RESTORE” and “NOURISH · BRIGHTEN.” Approve those against actual product records or replace them before treating the art as a finished retail label. “Organic-first” describes the development brief; it is not finished-product certification. Do not add universal skin-type claims, invented clinical results, ratings or testimonials.

## Store, fulfillment and owner operations

- [ ] Connect the owner's real Squarespace store and actual native Selfnamed integration. Synchronize approved SKUs/designs and configure billing, payment, shipping and taxes. Readiness flags alone are not evidence that this connection works.
- [ ] Resolve the cart handoff: the current custom preview cart does not transfer to Squarespace. The customer must use the real store cart for real orders unless an actual supported integration is implemented and verified.
- [ ] Complete an authorized end-to-end order: cart → payment → store order → manufacturer acceptance → production/packing → dispatch → carrier tracking → customer notifications. Check cancellation, refund, failed payment, rejected fulfillment and duplicate-event handling.
- [ ] Give the owner authenticated access to actual orders, payment status, fulfillment exceptions, tracking, refunds, stock and customer-care actions. Do not populate an admin dashboard with invented records. The local `orders` table presently stores payment-session metadata, not line-item fulfillment or carrier tracking.
- [ ] Confirm the return destination, merchant-funded return offer, refund timeframe and final shipping terms. Customer care is `supporteloraskin@gmail.com`; no response-time promise has been established.
- [ ] Connect a trusted review source with consent and moderation. “Verified purchase” must derive from a matching paid, fulfilled order; the current feed is deliberately empty.

The owner has authorized public publication of the pre-launch website. Keep ordering disabled until the product and store checks above are complete. Publishing the showcase does not activate real commerce or fulfillment.

## Customer tracking — 23 October 2026

The owner supplied the public AfterShip tracking-page URL, and the live form was verified to offer order-number/email and tracking-number lookup. `/track-order` embeds that form and offers a direct AfterShip link if embedding is unavailable. Navigation, Help, footer, shipping/return navigation and prepared chat answers lead to the tracking page. The owner reported connecting AfterShip to the Squarespace store. Actual order sync, carrier events and fulfillment remain unverified; this update does not open checkout or create orders.
