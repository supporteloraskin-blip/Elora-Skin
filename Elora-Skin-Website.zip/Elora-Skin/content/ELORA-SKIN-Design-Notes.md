# ELORA SKIN design and packaging notes

Personal attribution is withheld until the owner requests it. The presentation uses ivory, olive green, warm gold, editorial serif headings, and the original uncropped bottle-and-model composition. Cards, FAQs and Help remain prominent.

## Image production

All raster generation and edits used the built-in image-generation tool, not the CLI/API fallback. Source images remain preserved. The selected project assets are:

- `public/assets/elora-ritual-gold-v2.png` — original four bottles and portrait, 1671 × 941. Prompt: edit only the metallic chrome/silver-looking hardware to rich warm gold; preserve all bottle shapes, green caps, ivory bodies, white dropper rubber, labels, person, lighting, scene and framing. Keep all caps and bases visible.
- `public/assets/elora-next-chapter-gold-v3.png` — four additional packaging concepts, 1774 × 887. Initial prompt: a coordinated ELORA SKIN product concept lineup for Gentle Facial Scrub, Sunscreen, Cleansing Facial Pads and Facial Toner, with ivory bodies, olive lids, botanical branding, warm cream background, full packages in frame, and a Packaging Concepts heading. Subsequent edits warmed all metallic trim to gold and changed only the third package into an upright tall oval/rounded-rectangular ivory dispenser canister with a closed olive hinged flip-top lid, visible front lift tab/seam, and a warm gold band. Preserve the scrub, sunscreen, toner, typography, background and framing.

The selected pads edit is the generated source file `exec-bf621297-1ddb-4933-b56e-858fc92a89b9.png`. The selected original-bottle gold edit is `exec-9f0cf1bc-bdb7-4da3-af6b-062ea03e132e.png`.

The website uses SVG view boxes and clipping to present full individual packages from these images. No package cap or base is intentionally cropped. The illustration is a packaging design proposal, not a claim that a manufacturer sells these containers or formulas. It makes no SPF, organic certification or skin-type performance claim.


## Fine-mist toner update

- `public/assets/elora-next-chapter-gold-v4.png` — selected built-in image-generation precise-object edit from `exec-84ebb6f0-18b4-4507-ae88-132f30c6788a.png`. Only the far-right Facial Toner cap was changed to an olive-green fine-mist facial sprayer with a warm gold collar. The ivory toner body, label, other three products, cream background, typography, lighting, and framing were preserved. The original v3 asset remains available.
- The storefront now uses v4 for the coordinated upcoming-product lineup. The sprayer is a packaging concept; the manufacturer must confirm physical packaging availability and compatibility with the finished toner formula.
