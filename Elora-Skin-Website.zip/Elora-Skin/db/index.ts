import { env } from "cloudflare:workers";
import { drizzle } from "drizzle-orm/d1";
import * as schema from "./schema";

export function getDb() {
  if (!env.DB) {
    throw new Error(
      "Cloudflare D1 binding `DB` is unavailable. Create a D1 database and configure its real database_id for the DB binding in wrangler.jsonc before using the database."
    );
  }

  return drizzle(env.DB, { schema });
}
