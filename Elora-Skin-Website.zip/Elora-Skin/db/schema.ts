import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';

export const members = sqliteTable('members', {
  userId: text('user_id').primaryKey(),
  memberId: text('member_id').notNull().unique(),
  displayName: text('display_name').notNull(),
  cardStyle: text('card_style').notNull().default('olive'),
  favorites: text('favorites').notNull().default('[]'),
  moment: text('moment').notNull().default('morning'),
  createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const orders = sqliteTable('orders', {
  sessionId: text('session_id').primaryKey(),
  userId: text('user_id'),
  paymentStatus: text('payment_status').notNull().default('pending'),
  amountTotal: integer('amount_total').notNull().default(0),
  currency: text('currency').notNull().default('usd'),
  createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const chatRateLimits = sqliteTable('chat_rate_limits', {
  bucketKey: text('bucket_key').primaryKey(),
  used: integer('used').notNull().default(0),
  expiresAt: integer('expires_at').notNull(),
});
