# Cloudflare hosting preparation

Follow [README.md](README.md). The source has not been imported into GitHub or
Cloudflare yet. Replace the placeholder D1 database ID and configure private
access before any deployment. No public launch is authorized by this code copy.
